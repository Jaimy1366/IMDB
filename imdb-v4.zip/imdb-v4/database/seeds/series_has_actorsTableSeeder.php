<?php

use Illuminate\Database\Seeder;

class series_has_actorsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}

@extends('layouts.app')

@section('content')
    <p class="panel-tabs">
        <a  href="./"><<< go back</a>

    </p>
    <div class="container">
        <div class="level">
            {!! Form::open(['method'=>'post','url'=>'/series/search/','class'=>'navbar-form navbar-left','role'=>'search'])  !!}
                <div class="control search space_bottom">
                    <input type="text" class="input level-item" name="search" placeholder="Search...">
                    <button class="button is-dark level-item" type="submit">
                        <i class="fa fa-search">search</i>
                    </button>
                </div>
            {!! Form::close() !!}
        </div>
        <div class="is-flex">
            <div class="border-right space-top">
                <aside class="menu ">
                    <p class="menu-label">
                        Genres series
                    </p>
                    <ul class="menu-list">
                        @foreach($genres as $genre)
                            <li><a href="{{url('series/'. $genre->name .'/'.$genre->id)}}">{{$genre->name}}</a></li>
                        @endforeach
                    </ul>
                </aside>
            </div>
            <div class="container column">
                <div>

                </div>
                <p class="panel-heading">Series</p>
                @foreach($series as $serie)
                    <div class="panel-block">
                        <img src="{{asset('images/'. $serie->image)}}"/>
                        <div><a href="{{url('/series/'. $serie->id)}}">{{$serie->title}}</a></div>

                    </div>
                @endforeach
            </div>
        </div>
    </div>


@endsection
@extends('layouts.app')

@section('content')
    <p class="panel-tabs">
        <a  href="./"><<< go back</a>

    </p>
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Login
        </p>
        <div class="panel-block">
            <form class="form-horizontal " method="POST" action="{{ route('login') }}">
                <div class="field ">
                    {{ csrf_field() }}

                    <div class="control{{ $errors->has('email') ? ' has-error' : '' }}">
                        <label for="email" class="label-primary">E-Mail Address</label>
                        <input id="email" type="email" class="input" name="email" placeholder="E-Mail..." required autofocus>
                        @if ($errors->has('email'))
                            <span class="help-block">
                            <strong>{{ $errors->first('email') }}</strong>
                        </span>
                        @endif
                    </div>

                    <div class="control{{ $errors->has('password') ? ' has-error' : '' }}">
                        <label for="password" class="label-primary">Password</label>

                        <input id="password" type="password" class="input" name="password" required>

                        @if ($errors->has('password'))
                            <span class="help-block">
                            <strong>{{ $errors->first('password') }}</strong>
                        </span>
                        @endif
                    </div>
                    <div class="control">
                        <div class="checkbox">
                            <label class="label-info">
                                <input class="checkbox" type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> Remember Me
                            </label>
                        </div>
                    </div>
                    <div class="control">

                        <button type="submit" class="button top-spacing">
                            Login
                        </button>
                    </div>

                </div>



            </form>
        </div>

    </div>


@endsection

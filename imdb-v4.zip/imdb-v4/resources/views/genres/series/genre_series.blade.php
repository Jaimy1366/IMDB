@extends('layouts.app')

@section('content')
    <p class="panel-tabs">
        <a  href="../"><<< go back</a>

    </p>
    <div class="container column">
        <div class="is-flex">
            <div class="border-right space-top">
                <aside class="menu ">
                    <p class="menu-label">
                        Genres series
                    </p>
                    <ul class="menu-list">
                        @foreach($all_genres as $genre)
                            <li><a href="{{url('series/'. $genre->name .'/'.$genre->id)}}">{{$genre->name}}</a></li>
                        @endforeach
                    </ul>
                </aside>
            </div>
            <div class="container column">

                <p class="panel-heading">{{$genres->name}}</p>
                @foreach($genres->Serie as $serie)
                    <div class="panel-block">
                        <img src="{{asset('images/'. $serie->image)}}"/>
                        <div><a href="{{url('/series/'. $serie->id)}}">{{$serie->title}}</a></div>
                    </div>
                @endforeach
            </div>
        </div>

    </div>


@endsection

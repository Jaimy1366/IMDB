@extends('layouts.app')

@section('content')
    <p class="panel-tabs">
        <a  href="./"><<< go back</a>

    </p>
    <div class="container column is-half">
            <p class="panel-heading">Serie {{$serie->title}}</p>
            <div class="panel-block">
                <img src="{{asset('images/'. $serie->image)}}"/>
            </div>
            <div class="panel-block">
                {{$serie->description}}
            </div>
            <div class="panel-block">
                {{$serie->date_aired}}
            </div>

            <div class="panel-block">
                @foreach($serie->Actor as $actor)
                    {{$actor->name}},
                    @endforeach
            </div>
            <div class="container column is-full">
                <p class="panel-heading">Seasons and episodes</p>
                <table class="table panel-block">
                    @if(count($serie->seasons) > 0)
                        @foreach($serie->seasons as $season)
                            <tr>
                                <td>
                                    <b>{{$season->title}}</b>
                                </td>
                            </tr>
                            @foreach($season->episodes as $episode)
                                <tr>
                                    <td>
                                        {{ $episode->number }} / {{ $episode->name }}
                                    </td>
                                </tr>
                            @endforeach
                        @endforeach
                    @endif

                </table>
            </div>
        <div class="panel-block container column is-full">
            <p class="panel-heading">Comments</p>
            @foreach($serie->Comment as $comment)

                <div class="panel-block">
                    @foreach($user->where('id', $comment->users_id) as $users)
                        <div class="panel-block right-space">{{$users->name}}</div>
                    @endforeach
                    {{$comment->content}}
                    @if(Auth::check() && Auth::check() == 'Admin')
                        <div class="space_left">
                            {!! Form::open(['url' => 'series/' . $serie->id .'/'. $comment->id. '/delete', 'method' => 'delete']) !!}
                            {!! Form::submit('delete', ['class' => 'button is-danger']) !!}
                            {!! Form::close() !!}
                        </div>
                    @endif
                </div>
            @endforeach
            <form class="form-horizontal" method="POST" action="{{ url('/series/'. $serie->id. '/comment') }}">
                {{ csrf_field() }}
                <div class="control{{ $errors->has('comment') ? ' has-error' : '' }}">
                    <input id="comment" type="text" class="input" name="comment" placeholder="Comment something....." required autofocus>
                    @if ($errors->has('comment'))
                        <span class="help-block">
                            <p id="error">{{ $errors->first('comment') }}</p>
                        </span>
                    @endif
                </div>
                <div class="control">
                    @if(Auth::check())
                        <button type="submit" class="button is-dark">
                            Submit
                        </button>
                    @endif

                </div>
            </form>

        </div>
    </div>


@endsection
@extends('layouts.app')

@section('content')
    <p class="panel-tabs">
        <a  href="./"><<< go back</a>

    </p>
    <div class="container column ">
        <div class="is-flex">
            <div class="border-right space-top">
                <aside class="menu ">
                    <p class="menu-label">
                        Genres series
                    </p>
                    <ul class="menu-list">
                        @foreach($genres as $genre)
                            <li><a href="{{url('movies/'. $genre->name .'/'.$genre->id)}}">{{$genre->name}}</a></li>
                        @endforeach
                    </ul>
                </aside>
            </div>
            <div class="container column ">
                @if(empty($resultShow))
                    <div>
                        No result
                    </div>
                    @else
                        <p class="panel-heading">Search results</p>
                        @foreach($resultShow as $serie)
                            <div class="panel-block">
                                <img src="{{asset('images/'. $serie->image)}}"/>
                                <div><a href="{{url('/series/'. $serie->id)}}">{{$serie->title}}</a></div>
                            </div>
                        @endforeach
                    @endif

            </div>
        </div>

    </div>


@endsection

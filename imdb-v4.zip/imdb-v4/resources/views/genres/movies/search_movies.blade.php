@extends('layouts.app')

@section('content')
    <p class="panel-tabs">
        <a  href="./"><<< go back</a>

    </p>
    <div class="container column">
        <div class="is-flex">
            <div class="border-right space-top">
                <aside class="menu ">
                    <p class="menu-label">
                        Genres movies
                    </p>
                    <ul class="menu-list">
                        @foreach($genres as $genre)
                            <li><a href="{{url('movies/'. $genre->name .'/'.$genre->id)}}">{{$genre->name}}</a></li>
                        @endforeach
                    </ul>
                </aside>
            </div>
            <div class="container column">
                @if(empty($resultMovie))
                    <div>
                        No result
                    </div>
                    @else
                        <p class="panel-heading">Search results</p>
                        @foreach($resultMovie as $movie)
                            <div class="panel-block">
                                <img src="{{asset('images/'. $movie->image)}}"/>
                                <div><a href="{{url('/movies/'. $movie->id)}}">{{$movie->title}}</a></div>

                            </div>
                        @endforeach
                    @endif

            </div>
        </div>

    </div>


@endsection

@extends('layouts.app')

@section('content')
    <p class="panel-tabs">
        <a  href="./"><<< go back</a>

    </p>
    <div class="container column is-half">
            <p class="panel-heading">Movie {{$movie->title}}</p>
            <div class="panel-block">
                <img src="{{asset('images/'. $movie->image)}}"/>
            </div>
            <div class="panel-block">
                {{$movie->description}}
            </div>
            <div class="panel-block">
                {{$movie->date_aired}}
            </div>
            <div class="panel-block">
                {{$movie->duration}} minutes
            </div>
            <div class="panel-block">
                @foreach($movie->Actor as $actor)
                    {{$actor->name}},
                    @endforeach
            </div>
            <div class="panel-block container column is-full">
                <p class="panel-heading">Comments</p>
                @foreach($movie->Comment as $comment)
                    <div class="panel-block">
                        @foreach($user->where('id', $comment->users_id) as $users)
                            <div class="panel-block right-space">{{$users->name}}</div>
                        @endforeach

                        {{$comment->content}}
                        @if(Auth::check())
                            @if(Auth::user()->isAdmin() OR Auth::user()->id == $comment->users_id)
                                <div class="space_left">
                                    {!! Form::open(['url' => 'movies/' . $movie->id .'/'. $comment->id. '/delete', 'method' => 'delete']) !!}
                                    {!! Form::submit('delete', ['class' => 'button is-danger ']) !!}
                                    {!! Form::close() !!}
                                </div>
                            @endif
                        @endif


                    </div>
                    @endforeach
                    <form class="form-horizontal" method="POST" action="{{ url('/movies/'. $movie->id. '/comment') }}">
                        {{ csrf_field() }}
                        <div class="control{{ $errors->has('comment') ? ' has-error' : '' }}">
                            <input id="comment" type="text" class="input" name="comment" placeholder="Comment something....." required autofocus>
                            @if ($errors->has('comment'))
                                <span class="help-block">
                                    <p id="error">{{ $errors->first('comment') }}</p>
                                </span>
                            @endif
                        </div>
                        <div class="control">
                            @if(Auth::user())
                                <button type="submit" class="button is-dark">
                                    Submit
                                </button>
                                @endif

                        </div>
                    </form>

            </div>
    </div>


@endsection
@extends('layouts.app')
@section('dashboard')

    <div class="container column is-four-fifths-mobile is-four-fifths-tablet is-two-thirds-desktop panel ">
        <p class="panel-heading has-text-centered">
            <b>
                {{$serie->title}} seasons and episodes control panel
            </b>
        </p>
        <p class="panel-tabs">
            <a  href="../"><<< go back</a>
        </p>
        <div class="panel-block is-flex">
            <div class="container column ">
                <p class="panel-heading">Serie</p>
                <table class="table panel-block">
                    <tr>
                        <td>
                            <h4><b>Title</b></h4>
                        </td>
                        <td>
                            <h4><b>Description</b></h4>
                        </td>

                    </tr>
                    <tr>
                        <td>
                            <h5>{{$serie->title}}</h5>
                        </td>
                        <td>
                            <h5>{{$serie->description}}</h5>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="container column ">
                <p class="panel-heading">Seasons and episodes</p>
                <table class="table panel-block">
                    @if(count($serie->seasons) > 0)
                        @foreach($serie->seasons as $season)
                            <tr>
                                <td>
                                    <b>{{$season->title}}</b>
                                </td>
                                <td>
                                    {!! Form::open(['url' => 'admin-dashboard/Series/show/season_delete/'.$season->id, 'method' => 'delete']) !!}
                                    {!! Form::submit('delete', ['class' => 'button is-danger']) !!}
                                    {!! Form::close() !!}
                                </td>
                                <td>
                                    <a class="button is-link" href="{{url('admin-dashboard/Series/show/season_edit/'. $season->id)}}">Edit</a>
                                </td>
                            </tr>
                            @foreach($season->episodes as $episode)
                                <tr>
                                    <td>
                                        {{ $episode->number }} / {{ $episode->name }}
                                    </td>
                                    <td>
                                        {!! Form::open(['url' => 'admin-dashboard/Series/show/ep_delete/'.$episode->id, 'method' => 'delete']) !!}
                                        {!! Form::submit('delete', ['class' => 'button is-danger']) !!}
                                        {!! Form::close() !!}
                                    </td>
                                    <td>
                                        <a class="button is-link" href="{{url('admin-dashboard/Series/show/ep_edit/'. $episode->id)}}">Edit</a>
                                    </td>
                                </tr>
                            @endforeach
                        @endforeach
                    @endif
                    <tr>
                        <td>
                            <a class="right-space" href="{{url('admin-dashboard/Series/'. $serie['id']. '/show/ep_create')}}">
                                Add Episode
                            </a>
                        </td>
                        <td>
                            <a href="{{url('admin-dashboard/Series/'. $serie['id']. '/show/season_create')}}">
                                Add Season
                            </a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="panel-block is-flex">
            <div class="container column">
                <p class="panel-heading">Actors</p>
                <table class="table panel-block">
                    <tr>
                        <td>
                            <h4><b>Actors</b></h4>
                        </td>
                    </tr>
                    @foreach($serie->Actor as $actor)
                        <tr>
                            <td>
                                {{$actor->name}}
                            </td>
                            <td>
                                {!! Form::open(['url' => 'admin-dashboard/Series/'.$serie->id.'/show/actor_delete/'.$actor->id, 'method' => 'delete']) !!}
                                {!! Form::submit('remove', ['class' => 'button is-dark is-outlined']) !!}
                                {!! Form::close() !!}
                            </td>
                        </tr>
                    @endforeach
                    <tr>
                        <td>
                            <a href="{{url('admin-dashboard/Series/'. $serie['id']. '/show/add_actor')}}">
                                Add existing actor
                            </a>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="container column ">
                <p class="panel-heading">Genres</p>
                <table class="table panel-block">
                    <tr>

                        <td>
                            <h6><b>Genres</b></h6>
                        </td>
                    </tr>
                    @foreach($serie->Genre as $genre)
                        <tr>

                            <td>
                                {{$genre->name}}
                            </td>
                            <td>
                                {!! Form::open(['url' => 'admin-dashboard/Series/'. $serie->id. '/show/genre_delete/'.$genre->id, 'method' => 'delete']) !!}
                                {!! Form::submit('remove', ['class' => 'button is-dark is-outlined']) !!}
                                {!! Form::close() !!}
                            </td>
                        </tr>
                    @endforeach
                    <tr>
                        <td>
                            <a href="{{url('admin-dashboard/Series/'. $serie['id']. '/show/add_genre')}}">
                                Add existing genre
                            </a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

    </div>

@endsection
@extends('layouts.app')
@section('dashboard')

    <div class="container column is-four-fifths-mobile is-four-fifths-tablet is-two-thirds-desktop panel ">
        <p class="panel-heading has-text-centered">
            <b>
                Movie control panel
            </b>
        </p>
        <p class="panel-tabs">
            <a  href="./"><<< go back</a>

        </p>
        <div class="panel-block ">
            <table class="table column ">
                <tr>
                    <td>
                        <h4><b>Id</b></h4>
                    </td>

                    <td>
                        <h4><b>Title</b></h4>
                    </td>
                    <td>
                        <h4><b>Duration</b></h4>
                    </td>
                </tr>
                @foreach($movies as $movie)
                    <tr>
                        <td>
                            {{$movie->id}}
                        </td>
                        <td>
                            <h5>{{$movie->title}}</h5>
                        </td>
                        <td>
                            <h5>{{$movie->duration}}</h5>
                        </td>
                        <td>
                            <div >
                                {!! Form::open(['url' => 'admin-dashboard/Movies/' . $movie['id'], 'method' => 'delete']) !!}
                                {!! Form::submit('delete', ['class' => 'button is-danger']) !!}
                                {!! Form::close() !!}
                            </div>

                        </td>
                        <td >
                            <a class="button is-link" href="{{url('admin-dashboard/Movies/'. $movie->id .'/edit')}}">Edit</a>
                        </td>
                        <td >
                            <a class="button is-link" href="{{url('admin-dashboard/Movies/'. $movie->id .'/show')}}">Show</a>
                        </td>
                    </tr>

                @endforeach
                <tr class="add_movie_top_line">
                    <td>
                        <a href="{{url('admin-dashboard/Movies/create')}}">Add Movie</a>
                    </td>
                </tr>
            </table>

        </div>
    </div>

@endsection
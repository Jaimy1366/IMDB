@extends('layouts.app')
@section('dashboard')

    <div class="container column is-four-fifths-mobile is-four-fifths-tablet is-two-thirds-desktop panel ">
        <p class="panel-heading has-text-centered">
            <b>
                Genre controle panel
            </b>
        </p>
        <p class="panel-tabs">
            <a  href="./"><<< go back</a>
        </p>
        <div class="panel-block">
            <table class="table column">
                <tr>
                    <td>
                        <h4><b>Id</b></h4>
                    </td>
                    <td>
                        <h4><b>Name</b></h4>
                    </td>

                </tr>
                @foreach($genres as $genre)
                    <tr>
                        <td>
                            <h4> {{ $genre->id }}</h4>
                        </td>
                        <td>
                            <h4>{{$genre->name}}</h4>
                        </td>
                        <td>
                            <div >
                                {!! Form::open(['url' => 'admin-dashboard/Genres/' . $genre['id'], 'method' => 'delete']) !!}
                                {!! Form::submit('delete', ['class' => 'button is-danger']) !!}
                                {!! Form::close() !!}
                            </div>

                        </td>
                        <td >
                            <a class="button is-link" href="{{url('admin-dashboard/Genres/'. $genre->id .'/edit')}}">Edit</a>
                        </td>
                    </tr>
                @endforeach
                <tr class="add_movie_top_line">
                    <td>
                        <a href="{{url('admin-dashboard/Genres/create')}}">Add genre</a>
                    </td>
                </tr>
            </table>
        </div>
        @if(session("message"))
            <div class="panel-block">
                <p class="red"><b>{{session("message")}}</b></p>
            </div>
        @endif
    </div>

@endsection
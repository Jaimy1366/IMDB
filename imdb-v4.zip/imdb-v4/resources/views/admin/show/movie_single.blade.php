@extends('layouts.app')
@section('dashboard')

    <div class="container column is-four-fifths-mobile is-four-fifths-tablet is-two-thirds-desktop panel ">
        <p class="panel-heading has-text-centered">
            <b>
                {{$movie->title}}
            </b>
        </p>
        <p class="panel-tabs">
            <a  href="../"><<< go back</a>

        </p>

        <div class="panel-block level">
            <div class="container column level-left">
                <p class="panel-heading">Movie</p>
                <table class="table panel-block">
                    <tr>
                        <td>
                            <h4><b>Title</b></h4>
                        </td>
                        <td>
                            <h4><b>Date aired</b></h4>
                        </td>
                        <td>
                            <h4><b>Description</b></h4>
                        </td>

                    </tr>
                    <tr>
                        <td>
                            <h5>{{$movie->title}}</h5>
                        </td>
                        <td>
                            <h5>{{$movie->date_aired}}</h5>
                        </td>
                        <td>
                            <h5>{{$movie->description}}</h5>
                        </td>
                    </tr>
                </table>
            </div>

        </div>
        <div class="panel-block is-flex">
            <div class="container column">
                <p class="panel-heading">Actors</p>
                <table class="table panel-block">
                    <tr>
                        <td>
                            <h4><b>Actors</b></h4>
                        </td>
                    </tr>
                    @foreach($movie->Actor as $actor)
                        <tr>
                            <td>
                                {{$actor->name}}
                            </td>
                            <td>
                                {!! Form::open(['url' => 'admin-dashboard/Movies/'.$movie->id.'/show/actor_delete/'.$actor->id, 'method' => 'delete']) !!}
                                {!! Form::submit('remove', ['class' => 'button is-dark is-outlined']) !!}
                                {!! Form::close() !!}
                            </td>
                        </tr>
                    @endforeach
                    <tr>
                        <td>
                            <a href="{{url('admin-dashboard/Movies/'. $movie['id']. '/show/add_actor')}}">
                                Add existing actor
                            </a>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="container column ">
                <p class="panel-heading">Genres</p>
                <table class="table panel-block">
                    <tr>

                        <td>
                            <h6><b>Genres</b></h6>
                        </td>
                    </tr>
                    @foreach($movie->Genre as $genre)
                        <tr>

                            <td>
                                {{$genre->name}}
                            </td>
                            <td>
                                {!! Form::open(['url' => 'admin-dashboard/Movies/'. $movie->id. '/show/genre_delete/'.$genre->id, 'method' => 'delete']) !!}
                                {!! Form::submit('remove', ['class' => 'button is-dark is-outlined']) !!}
                                {!! Form::close() !!}
                            </td>
                        </tr>
                    @endforeach
                    <tr>
                        <td>
                            <a href="{{url('admin-dashboard/Movies/'. $movie['id']. '/show/add_genre')}}">
                                Add existing genre
                            </a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

    </div>

@endsection
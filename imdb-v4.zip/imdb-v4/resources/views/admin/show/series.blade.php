@extends('layouts.app')
@section('dashboard')

    <div class="container column is-four-fifths-mobile is-four-fifths-tablet is-two-thirds-desktop panel ">
        <p class="panel-heading has-text-centered">
            <b>
                Serie control panel
            </b>
        </p>
        <p class="panel-tabs">
            <a  href="./"><<< go back</a>

        </p>
        <div class="panel-block ">
            <table class="table column ">
                <tr>
                    <td>
                        <h4><b>Id</b></h4>
                    </td>
                    <td>
                        <h4><b>Image</b></h4>
                    </td>
                    <td>
                        <h4><b>Title</b></h4>
                    </td>
                    <td>
                        <h4><b>Description</b></h4>
                    </td>
                    <td>
                        <h4><b>date aired</b></h4>
                    </td>
                </tr>
                @foreach($series as $serie)
                    <tr>
                        <td>
                            {{$serie->id}}
                        </td>
                        <td>
                            <h5> {{$serie->data}}</h5>
                        </td>
                        <td>
                            <h5>{{$serie->title}}</h5>
                        </td>
                        <td>
                            <h5>{{$serie->description}}</h5>
                        </td>
                        <td>
                            <h5>{{$serie->date_aired}}</h5>
                        </td>
                        <td>
                            <div >
                                {!! Form::open(['url' => 'admin-dashboard/Series/' . $serie['id'], 'method' => 'delete']) !!}
                                {!! Form::submit('delete', ['class' => 'button is-danger']) !!}
                                {!! Form::close() !!}
                            </div>

                        </td>
                        <td >
                            <a class="button is-link" href="{{url('admin-dashboard/Series/'. $serie->id .'/edit')}}">Edit</a>
                        </td>
                        <td >
                            <a class="button is-link" href="{{url('admin-dashboard/Series/'. $serie->id .'/show')}}">Episodes</a>
                        </td>
                    </tr>
                @endforeach
                <tr class="add_movie_top_line">
                    <td>
                        <a href="{{url('admin-dashboard/Series/create')}}">Add Serie</a>
                    </td>

                </tr>
            </table>

        </div>
    </div>

@endsection
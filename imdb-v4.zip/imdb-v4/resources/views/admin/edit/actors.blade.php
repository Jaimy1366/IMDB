@extends('layouts.app')

@section('content')
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Editing Actor {{ $actors->name }}
        </p>
        <div class="panel-block">
            {!! Form::open(['url' => '/admin-dashboard/Actors/edit/'. $actors['id'] , 'method' => 'patch']) !!}

            <div>
                <div class="control">
                    {!! Form::label("name : ", 'name : ' , ['class' => 'label-info']) !!}
                    {!! Form::text('name', $actors->name, ['class' => 'input'] )!!}
                </div>

                <div class="control">
                    {!! Form::submit('Verstuur' , ['class' => 'button is-dark']) !!}
                </div>
            </div>

            {!! Form::close() !!}
        </div>

    </div>
@endsection

@extends('layouts.app')

@section('content')
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Editing Episode {{ $episodes->name }}
        </p>

        <div class="panel-block">
            {!! Form::open(['url' => 'admin-dashboard/Series/show/ep_edit/'.$episodes->id , 'method' => 'patch']) !!}

            <div>
                <div class="control">
                    {!! Form::label("name : ", 'name : ' , ['class' => 'label-info']) !!}
                    {!! Form::text('name', $episodes->name, ['class' => 'input'] )!!}
                </div>

                <div class="control">
                    {!! Form::label("number : ", 'number : ' , ['class' => 'label-info']) !!}
                    {!! Form::text('number', $episodes->number , ['class' => 'input'] )!!}
                </div>

                <div class="control">
                    <label for="season_id" class="label-info">Season</label>
                    <select id="season_id"  class="select" name="season_id" required>
                        @foreach($seasons as $season)
                            <option value="{{$season->id}}">{{$season->title}}</option>

                        @endforeach
                    </select>
                </div>

                <div class="control">
                    {!! Form::submit('Verstuur' , ['class' => 'button is-dark']) !!}
                </div>


            </div>

            {!! Form::close() !!}
        </div>

    </div>
@endsection
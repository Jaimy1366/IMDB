@extends('layouts.app')

@section('content')
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Editing Role {{ $roles->name }}
        </p>
        <div class="panel-block">
            {!! Form::open(['url' => '/admin-dashboard/Roles/edit/'. $roles['id'] , 'method' => 'patch']) !!}

            <div>
                <div class="control">
                    {!! Form::label("name : ", 'name : ' , ['class' => 'label-info']) !!}
                    {!! Form::text('name', $roles->name, ['class' => 'input'] )!!}
                </div>

                <div class="control">
                    {!! Form::submit('Verstuur' , ['class' => 'button is-dark']) !!}
                </div>
            </div>

            {!! Form::close() !!}
        </div>

    </div>
@endsection

@extends('layouts.app')

@section('content')
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Editing User {{ $users->name }}
        </p>
        <div class="panel-block">
            {!! Form::open(['url' => '/admin-dashboard/Users/edit/'. $users['id'] , 'method' => 'patch']) !!}

                <div>
                    <div class="control">
                        {!! Form::label("name : ", 'name : ' , ['class' => 'label-info']) !!}
                        {!! Form::text('name', $users->name, ['class' => 'input'] )!!}
                    </div>

                    <div class="control">
                        {!! Form::label("email : ", 'email : ' , ['class' => 'label-info']) !!}
                        {!! Form::email('email', $users->email , ['class' => 'input'] )!!}
                    </div>
                    <div class="control">
                        {!! Form::label("role : ", 'role : ' , ['class' => 'label-info']) !!}
                        {!! Form::select('role', [
                           '1' => 'Admin',
                           '2' => 'User'], ['class' => 'select']
                        ) !!}


                    </div>

                    <div class="control">
                        {!! Form::submit('Verstuur' , ['class' => 'button is-dark']) !!}
                    </div>


                </div>

            {!! Form::close() !!}
        </div>

    </div>
@endsection

@extends('layouts.app')

@section('content')
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Editing Movie {{ $movies->title }}
        </p>
        <div class="panel-block">
            {!! Form::open(['url' => '/admin-dashboard/Movies/edit/'. $movies['id'] , 'method' => 'patch','files' => true] ) !!}

            <div>
                <div class="control">
                    {!! Form::label("title : ", 'title : ' , ['class' => 'label-info']) !!}
                    {!! Form::text('title', $movies->title, ['class' => 'input'] )!!}
                </div>

                <div class="control">
                    {!! Form::label("date_aired : ", 'date_aired : ' , ['class' => 'label-info']) !!}
                    {!! Form::date('date_aired', $movies->date_aired , ['class' => 'input'] )!!}
                </div>
                <div class="control">
                    {!! Form::label("description : ", 'description : ' , ['class' => 'label-info']) !!}
                    {!! Form::textarea('description', $movies->description , ['class' => 'input'] )!!}
                </div>
                <div class="control">
                    {!! Form::label("duration : ", 'duration : ' , ['class' => 'label-info']) !!}
                    {!! Form::text('duration', $movies->duration , ['class' => 'input'] )!!}
                </div>

                <div class="control">
                    {!! Form::label("img : ", 'img : ', ['class' => 'label-info']) !!}
                    {!! Form::file('img') !!}
                </div>

                <div class="control">
                    {!! Form::submit('Verstuur' , ['class' => 'button is-dark']) !!}
                </div>


            </div>

            {!! Form::close() !!}
        </div>

    </div>
@endsection

@extends('layouts.app')

@section('content')
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Editing Season {{ $seasons->title }}
        </p>

        <div class="panel-block">
            {!! Form::open(['url' => 'admin-dashboard/Series/show/season_edit/'.$seasons->id , 'method' => 'patch']) !!}

            <div>
                <div class="control">
                    {!! Form::label("title : ", 'title : ' , ['class' => 'label-info']) !!}
                    {!! Form::text('title', $seasons->title, ['class' => 'input'] )!!}
                </div>

                <div class="control">
                    {!! Form::label("description : ", 'description : ' , ['class' => 'label-info']) !!}
                    {!! Form::text('description', $seasons->description , ['class' => 'input'] )!!}
                </div>

                <div class="control">
                    {!! Form::submit('Verstuur' , ['class' => 'button is-dark']) !!}
                </div>


            </div>

            {!! Form::close() !!}
        </div>

    </div>
@endsection
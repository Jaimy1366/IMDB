@extends('layouts.app')

@section('content')
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Editing Serie {{ $series->title }}
        </p>
        <div class="panel-block">
            {!! Form::open(['url' => '/admin-dashboard/Series/edit/'. $series['id'] , 'method' => 'patch', 'files' => true]) !!}

            <div>
                <div class="control">
                    {!! Form::label("title : ", 'title : ' , ['class' => 'label-info']) !!}
                    {!! Form::text('title', $series->title, ['class' => 'input'] )!!}
                </div>

                <div class="control">
                    {!! Form::label("date_aired : ", 'date_aired : ' , ['class' => 'label-info']) !!}
                    {!! Form::date('date_aired', $series->date_aired , ['class' => 'input'] )!!}
                </div>
                <div class="control">
                    {!! Form::label("description : ", 'description : ' , ['class' => 'label-info']) !!}
                    {!! Form::textarea('description', $series->description , ['class' => 'input'] )!!}
                </div>

                <div class="control">
                    {!! Form::label("img : ", 'img : ', ['class' => 'label-info']) !!}
                    {!! Form::file('img') !!}
                </div>

                <div class="control">
                    {!! Form::submit('Verstuur' , ['class' => 'button is-dark']) !!}
                </div>

            </div>

            {!! Form::close() !!}
        </div>

    </div>
@endsection

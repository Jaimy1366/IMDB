@extends('layouts.app')

@section('content')
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Add existing Actor
        </p>
        <div class="panel-block">
            <form class="form-horizontal" method="POST" action="{{url('admin-dashboard/Series/'. $serie['id']. '/show/add_actor')}}">
                {{ csrf_field() }}

                <div class="control{{ $errors->has('actors_id') ? ' has-error' : '' }}">
                    <label for="actors_id" class="label-info">Actor</label>
                    <select id="actors_id" type="text" class="input" name="actors_id" required autofocus>
                        @foreach($actors as $actor)
                            <option value="{{$actor->id}}">{{$actor->name}}</option>
                        @endforeach
                    </select>

                </div>

                <div class="control">
                    <button type="submit" class="button is-dark">
                        Add actor
                    </button>
                </div>

            </form>
        </div>

    </div>
@endsection
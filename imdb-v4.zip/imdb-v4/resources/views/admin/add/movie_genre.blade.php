@extends('layouts.app')

@section('content')
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Add existing Genre
        </p>
        <div class="panel-block">
            <form class="form-horizontal" method="POST" action="{{url('admin-dashboard/Movies/'. $movie['id']. '/show/add_genre')}}">
                {{ csrf_field() }}

                <div class="control{{ $errors->has('genres_id') ? ' has-error' : '' }}">
                    <label for="genres_id" class="label-info">Genre</label>
                    <select id="genres_id" type="text" class="input" name="genres_id" required autofocus>
                        @foreach($genres as $genre)
                            <option value="{{$genre->id}}">{{$genre->name}}</option>
                        @endforeach
                    </select>

                </div>

                <div class="control">
                    <button type="submit" class="button is-dark">
                        Add genre
                    </button>
                </div>

            </form>
        </div>

    </div>
@endsection
@extends('layouts.app')

@section('content')
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Create new Season
        </p>
        <p class="panel-tabs">
            <a  href="./"><<< go back</a>

        </p>
        <div class="panel-block">
            <form class="form-horizontal" method="POST" action="{{ url('admin-dashboard/Series/'. $series['id'].'/show/season_create') }}">
                {{ csrf_field() }}

                <div class="control{{ $errors->has('title') ? ' has-error' : '' }}">
                    <label for="title" class="label-info">Title</label>
                    <input id="title" type="text" class="input" name="title" placeholder="Title..." required autofocus>
                    @if ($errors->has('title'))
                        <span class="help-block">
                            <p id="error">{{ $errors->first('title') }}</p>
                        </span>
                    @endif
                </div>

                <div class="control{{ $errors->has('description') ? ' has-error' : '' }}">
                    <label for="description" class="label-info">Description</label>
                    <textarea id="description" type="text" class="input" name="description" placeholder="Description..." required autofocus></textarea>
                    @if ($errors->has('description'))
                        <span class="help-block">
                            <p id="error">{{ $errors->first('description') }}</p>
                        </span>
                    @endif
                </div>

                <div class="control">
                    <button type="submit" class="button is-dark">
                        Add season
                    </button>
                </div>

            </form>
        </div>

    </div>
@endsection

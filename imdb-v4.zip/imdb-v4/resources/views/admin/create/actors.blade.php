@extends('layouts.app')

@section('content')
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Create new Actor
        </p>
        <div class="panel-block">
            <form class="form-horizontal" method="POST" action="{{ url('admin-dashboard/Actors/create') }}">
                {{ csrf_field() }}

                <div class="control{{ $errors->has('name') ? ' has-error' : '' }}">
                    <label for="name" class="label-info">Name</label>
                    <input id="name" type="text" class="input" name="name" value="{{ old('name') }}" required autofocus>
                    @if ($errors->has('name'))
                        <span class="help-block">
                        <p id="error">{{ $errors->first('name') }}</p>
                    </span>
                    @endif
                </div>

                <div class="control">
                    <button type="submit" class="button is-dark">
                        Add actor
                    </button>
                </div>

            </form>
        </div>

    </div>
@endsection

@extends('layouts.app')

@section('content')
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Create new Episode
        </p>
        <p class="panel-tabs">
            <a  href="./"><<< go back</a>

        </p>
        <div class="panel-block">
            <form class="form-horizontal" method="POST" action="{{ url('admin-dashboard/Series/'. $serie->id.'/show/ep_create') }}">
                {{ csrf_field() }}

                <div class="control{{ $errors->has('name') ? ' has-error' : '' }}">
                    <label for="name" class="label-info">Name</label>
                    <input id="name" type="text" class="input" name="name" placeholder="Name..." required autofocus>
                    @if ($errors->has('name'))
                        <span class="help-block">
                            <p id="error">{{ $errors->first('name') }}</p>
                        </span>
                    @endif
                </div>

                <div class="control{{ $errors->has('number') ? ' has-error' : '' }}">
                    <label for="number" class="label-info">number</label>
                    <input id="number" type="text" class="input" name="number" placeholder="S01E01" required autofocus/>
                    @if ($errors->has('number'))
                        <span class="help-block">
                            <p id="error">{{ $errors->first('number') }}</p>
                        </span>
                    @endif
                </div>

                <div class="control{{ $errors->has('season_id') ? ' has-error' : '' }}">
                    <label for="season_id" class="label-info">Season</label>
                    <select id="season_id" type="text" class="input" name="season_id"  required autofocus>
                        @foreach($serie->seasons as $season)
                            <option value="{{$season->id}}">{{$season->title}}</option>
                        @endforeach
                    </select>
                    @if ($errors->has('season_id'))
                        <span class="help-block">
                            <p id="error">{{ $errors->first('season_id') }}</p>
                        </span>
                    @endif
                </div>


                <div class="control">
                    <button type="submit" class="button is-dark">
                        Add episode
                    </button>
                </div>

            </form>
        </div>

    </div>
@endsection

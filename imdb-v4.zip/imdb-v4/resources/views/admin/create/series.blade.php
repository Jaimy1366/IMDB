@extends('layouts.app')

@section('content')
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Create new Serie
        </p>
        <div class="panel-block">
            <form class="form-horizontal" method="POST" action="{{ url('admin-dashboard/Series/create') }}" enctype="multipart/form-data">
                {{ csrf_field() }}

                <div class="control{{ $errors->has('title') ? ' has-error' : '' }}">
                    <label for="title" class="label-info">Title</label>
                    <input id="title" type="text" class="input" name="title" placeholder="Title..." required autofocus>
                    @if ($errors->has('title'))
                        <span class="help-block">
                        <p id="error">{{ $errors->first('title') }}</p>
                    </span>
                    @endif
                </div>

                <div class="control{{ $errors->has('date_aired') ? ' has-error' : '' }}">
                    <label for="date_aired" class="label-info">Date aired</label>
                    <input id="date_aired" type="date" class="input" name="date_aired" placeholder="Date_aired..." required autofocus>
                    @if ($errors->has('title'))
                        <span class="help-block">
                        <p id="error">{{ $errors->first('date_aired') }}</p>
                    </span>
                    @endif
                </div>

                <div class="control{{ $errors->has('description') ? ' has-error' : '' }}">
                    <label for="description" class="label-info">description</label>
                    <input id="description" type="text" class="input" name="description" placeholder="Description..." required autofocus>
                    @if ($errors->has('title'))
                        <span class="help-block">
                        <p id="error">{{ $errors->first('description') }}</p>
                    </span>
                    @endif
                </div>

                <div class="control{{ $errors->has('img') ? ' has-error' : '' }}">
                    <label for="img" class="label-info">Img</label>
                    <input id="img" type="file" class="input" name="img" placeholder="Img..." required autofocus>
                </div>


                <div class="control">
                    <button type="submit" class="button is-dark">
                        Add serie
                    </button>
                </div>

            </form>
        </div>

    </div>
@endsection

@extends('layouts.app')

@section('content')
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Create new User
        </p>
        <div class="panel-block">
            <form class="form-horizontal" method="POST" action="{{ url('admin-dashboard/Users/create') }}">
                {{ csrf_field() }}

                <div class="control{{ $errors->has('name') ? ' has-error' : '' }}">
                    <label for="name" class="label-info">Name</label>
                    <input id="name" type="text" class="input" name="name" value="{{ old('name') }}" required autofocus>
                    @if ($errors->has('name'))
                        <span class="help-block">
                        <p id="error">{{ $errors->first('name') }}</p>
                    </span>
                    @endif
                </div>

                <div class="control{{ $errors->has('email') ? ' has-error' : '' }}">
                    <label for="email" class="label-info">E-Mail Address</label>
                    <input id="email" type="email" class="input" name="email" value="{{ old('email') }}" required>
                    @if ($errors->has('email'))
                        <span class="help-block">
                        <p id="error">{{ $errors->first('email') }}</p>
                    </span>
                    @endif
                </div>

                <div class="control{{ $errors->has('password') ? ' has-error' : '' }}">
                    <label for="password" class="label-info">Password</label>
                    <input id="password" type="password" class="input" name="password" required>
                    @if ($errors->has('password'))
                        <span class="help-block">
                        <p id="error">{{ $errors->first('password') }}</p>
                    </span>
                    @endif
                </div>

                <div class="control">
                    <label for="password-confirm" class="label-info">Confirm Password</label>
                    <input id="password-confirm" type="password" class="input" name="password_confirmation" required>
                </div>

                <div class="control">
                    <label for="role" class="label-info">Role</label>
                    <select id="role"  class="select" name="role" required>
                        @foreach($roles as $role)
                            <option value="{{$role->id}}">{{$role->name}}</option>
                            @endforeach
                    </select>
                </div>

                <div class="control">
                    <button type="submit" class="button is-dark">
                        Add user
                    </button>
                </div>

            </form>
        </div>

    </div>
@endsection

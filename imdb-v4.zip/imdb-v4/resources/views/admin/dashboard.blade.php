@extends('layouts.app')

@section('dashboard')

    <div class="container column is-mobile is-two-thirds-tablet is-half-desktop panel ">
        <p class="is-dark panel-heading has-text-centered ">
            <b>
                Dashboard
            </b>
        </p>
        <p class="panel-tabs">
            <a  href="{{url('admin-dashboard')}}">all</a>
            <a  href="{{url('admin-dashboard/Users')}}">Users</a>
            <a  href="{{url('admin-dashboard/Roles')}}">Roles</a>
            <a  href="{{url('admin-dashboard/Actors')}}">Actors</a>
            <a  href="{{url('admin-dashboard/Genres')}}">Genres</a>
            <a  href="{{url('admin-dashboard/Movies')}}">Movies</a>
            <a  href="{{url('admin-dashboard/Series')}}">Series</a>

        </p>
        <div class="panel-block">
            <p>Admins can use their admin permissions here</p>

        </div>
    </div>

@endsection
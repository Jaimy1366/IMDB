@extends('layouts.app')

@section('content')
    <p class="panel-tabs">
        <a  href="./"><<< go back</a>

    </p>
    <div class="container">
        <div class="level">
            {!! Form::open(['method'=>'post','url'=>'/movies/search/','role'=>'search'])  !!}
                <div class="control search space_bottom">
                    <input type="text" class="input level-item" name="search" placeholder="Search...">
                    <button class="button is-dark level-item" type="submit">
                        <i class="fa fa-search">search</i>
                    </button>
                </div>
            {!! Form::close() !!}

        </div>
        <div class="is-flex">
            <div class="border-right space-top">
                <aside class="menu ">
                    <p class="menu-label">
                        Genres movies
                    </p>
                    <ul class="menu-list ">
                        @foreach($genres as $genre)
                            <li><a href="{{url('movies/'. $genre->name .'/'.$genre->id)}}">{{$genre->name}}</a></li>
                        @endforeach
                    </ul>
                </aside>
            </div>
            <div class="container column ">

                <p class="panel-heading">Movies</p>
                @foreach($movies as $movie)
                    <div class="panel-block">
                        <img src="{{asset('images/'. $movie->image)}}"/>
                        <div><a href="{{url('/movies/'. $movie->id)}}">{{$movie->title}}</a></div>

                    </div>
                @endforeach
            </div>
        </div>
    </div>


@endsection
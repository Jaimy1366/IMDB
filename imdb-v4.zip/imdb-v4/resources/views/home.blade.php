@extends('layouts.app')

@section('content')

    <div class=" hero homepage_content is-light">
        <div class="is-flex">
            @foreach($movies as $movie)
                <div class="">
{{--
                    <p class="panel-heading">{{$movie->title}}</p>
--}}
                    <img src="{{asset('images/'. $movie->image)}}">
                    <div class="caption">
                        <p>{{$movie->title}}</p>
                    </div>
                </div>
                @endforeach
        </div>
        <div class="is-flex space-top">
            @foreach($series as $serie)

                <div class="">
{{--
                    <p class="panel-heading">{{$serie->title}}</p>
--}}
                    <img class="panel-body" src="{{asset('images/'. $serie->image)}}">
                    <div class="caption ">
                        <p>{{$serie->title}}</p>
                    </div>
                </div>

                @endforeach
        </div>
    </div>
@endsection

@extends('layouts.app')

@section('content')
    <a href="../" ><h1 class="button is-danger" style="color: white; font-size: 120px" ><b>This function is not working yet</b></h1></a>

@endsection
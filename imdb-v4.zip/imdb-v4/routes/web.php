<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'homepageController@index');

Auth::routes();

Route::get('/home', 'HomeController@index')->name('home');

Route::group(['middleware' => ['auth', 'Admin']], function () {
    //all routes in here use middleware auth Admin

    Route::group(['prefix' => 'admin-dashboard'], function () {
        //all routes in here have a prefixed part of the url called admin-dashboard
        Route::resource('Users', 'UserController');
        Route::group(['prefix' => 'Users'], function () {
            Route::get('create', 'UserController@create');
            Route::get('edit/{id}', 'UserController@edit');
            Route::patch('edit/{id}', 'UserController@update');
            Route::post('create', 'UserController@store');
            Route::delete('{id}', 'UserController@destroy');
        });


        Route::resource('Roles', 'RoleController');
        Route::group(['prefix' => 'Roles'], function () {
            Route::view('create', 'admin.create.roles');
            Route::get('edit/{id}', 'RoleController@edit');
            Route::patch('edit/{id}', 'RoleController@update');
            Route::post('create', 'RoleController@store');
            Route::delete('{id}', 'RoleController@destroy');
        });


        Route::resource('Actors', 'ActorController');
        Route::group(['prefix' => 'Actors'], function () {
            Route::view('create', 'admin.create.actors');
            Route::get('edit/{id}', 'ActorController@edit');
            Route::patch('edit/{id}', 'ActorController@update');
            Route::post('create', 'ActorController@store');
            Route::delete('{id}', 'ActorController@destroy');
        });

        Route::resource('Genres', 'GenreController');
        Route::group(['prefix' => 'Genres'], function () {
            Route::view('create', 'admin.create.genres');
            Route::get('edit/{id}', 'GenreController@edit');
            Route::patch('edit/{id}', 'GenreController@update');
            Route::post('create', 'GenreController@store');
            Route::delete('{id}', 'GenreController@destroy');
        });

        Route::resource('Movies', 'MovieController');
        Route::group(['prefix' => 'Movies'], function () {
            Route::view('create', 'admin.create.movies');
            Route::get('{id}/show/add_genre','MovieController@add_genre_page');
            Route::get('{id}/show/add_actor','MovieController@add_actor_page');
            Route::get('{id}/show', 'MovieController@show');
            Route::get('edit/{id}', 'MovieController@edit');
            Route::post('create', 'MovieController@store');
            Route::post('{id}/show/add_genre','MovieController@add_genre');
            Route::post('{id}/show/add_actor','MovieController@add_actor');
            Route::patch('edit/{id}', 'MovieController@update');
            Route::delete('{id}', 'MovieController@destroy');
            Route::delete('{id_movie}/show/actor_delete/{id_actor}', 'MovieController@destroy_actor');
            Route::delete('{id_movie}/show/genre_delete/{id_genre}', 'MovieController@destroy_genre');
        });

        Route::resource('Series', 'SerieController');
        Route::group(['prefix' => 'Series'], function (){
            Route::view('create', 'admin.create.series');
            Route::get('{id}/show/add_genre','SerieController@add_genre_page');
            Route::get('{id}/show/add_actor','SerieController@add_actor_page');
            Route::get('edit/{id}', 'SerieController@edit');
            Route::patch('edit/{id}', 'SerieController@update');
            Route::post('create', 'SerieController@store');
            Route::post('{id}/show/add_genre','SerieController@add_genre');
            Route::post('{id}/show/add_actor','SerieController@add_actor');
            Route::delete('{id}', 'SerieController@destroy');
            Route::delete('{id_serie}/show/actor_delete/{id_actor}', 'SerieController@destroy_actor');
            Route::delete('{id_serie}/show/genre_delete/{id_genre}', 'SerieController@destroy_genre');


            Route::get('{id}/show', 'SerieController@show');
            //following routes are for the season and episodes from series
            Route::get('{id}/show/ep_create', 'EpisodeController@create');
            Route::post('{id}/show/ep_create', 'EpisodeController@store');
            Route::get('show/ep_edit/{id}', 'EpisodeController@edit');
            Route::patch('show/ep_edit/{id}', 'EpisodeController@update');
            Route::delete('show/ep_delete/{id}', 'EpisodeController@destroy');

            Route::get('{id}/show/season_create', 'SeasonController@create');
            Route::post('{id}/show/season_create', 'SeasonController@store');
            Route::get('show/season_edit/{id}', 'SeasonController@edit');
            Route::patch('show/season_edit/{id}', 'SeasonController@update');
            Route::delete('show/season_delete/{id}', 'SeasonController@destroy');

        });
    });
});

Route::get('admin-dashboard', ['middleware' => ['auth', 'Admin'], function () {
    return view('admin.dashboard');
}]);

Route::get('/movies' , 'MovieController@movies');
Route::get('/movies/{Genre_name}/{Genre_id}' , 'MovieController@genre_movies');
Route::get('/movies/{movie_id}', 'MovieController@show_public');
Route::post('/movies/{movie_id}/comment', 'CommentController@store_movie');
Route::post('/movies/search/', 'searchController@search_movies');
Route::delete('/movies/{movie_id}/{comment_id}/delete' , 'CommentController@destroy_mc');

Route::get('/series' , 'SerieController@series');
Route::get('/series/{Genre_name}/{Genre_id}' , 'SerieController@genre_series');
Route::get('/series/{serie_id}', 'SerieController@show_public');
Route::post('/series/{serie_id}/comment', 'CommentController@store_serie');
Route::post('/series/search/', 'searchController@search_series');
Route::delete('/series/{serie_id}/{comment_id}/delete' , 'CommentController@destroy_sc');

//Route::get('/movies/search', 'MovieController@view_search');










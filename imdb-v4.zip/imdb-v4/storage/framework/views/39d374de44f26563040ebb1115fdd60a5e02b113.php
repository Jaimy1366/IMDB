<?php $__env->startSection('content'); ?>
    <p class="panel-tabs">
        <a  href="./"><<< go back</a>

    </p>
    <div class="container column">
        <div class="is-flex">
            <div class="border-right space-top">
                <aside class="menu ">
                    <p class="menu-label">
                        Genres movies
                    </p>
                    <ul class="menu-list">
                        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(url('movies/'. $genre->name .'/'.$genre->id)); ?>"><?php echo e($genre->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </aside>
            </div>
            <div class="container column">
                <?php if(empty($resultMovie)): ?>
                    <div>
                        No result
                    </div>
                    <?php else: ?>
                        <p class="panel-heading">Search results</p>
                        <?php $__currentLoopData = $resultMovie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="panel-block">
                                <img src="<?php echo e(asset('images/'. $movie->image)); ?>"/>
                                <div><a href="<?php echo e(url('/movies/'. $movie->id)); ?>"><?php echo e($movie->title); ?></a></div>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <p class="panel-tabs">
        <a  href="./"><<< go back</a>

    </p>
    <div class="container column is-half">
            <p class="panel-heading">Movie <?php echo e($movie->title); ?></p>
            <div class="panel-block">
                <img src="<?php echo e(asset('images/'. $movie->image)); ?>"/>
            </div>
            <div class="panel-block">
                <?php echo e($movie->description); ?>

            </div>
            <div class="panel-block">
                <?php echo e($movie->date_aired); ?>

            </div>
            <div class="panel-block">
                <?php echo e($movie->duration); ?> minutes
            </div>
            <div class="panel-block">
                <?php $__currentLoopData = $movie->Actor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($actor->name); ?>,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="panel-block container column is-full">
                <p class="panel-heading">Comments</p>
                <?php $__currentLoopData = $movie->Comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel-block">
                        <?php $__currentLoopData = $user->where('id', $comment->users_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="panel-block right-space"><?php echo e($users->name); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <?php echo e($comment->content); ?>

                        <?php if(Auth::check()): ?>
                            <?php if(Auth::user()->isAdmin() OR Auth::user()->id == $comment->users_id): ?>
                                <div class="space_left">
                                    <?php echo Form::open(['url' => 'movies/' . $movie->id .'/'. $comment->id. '/delete', 'method' => 'delete']); ?>

                                    <?php echo Form::submit('delete', ['class' => 'button is-danger ']); ?>

                                    <?php echo Form::close(); ?>

                                </div>
                            <?php endif; ?>
                        <?php endif; ?>


                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <form class="form-horizontal" method="POST" action="<?php echo e(url('/movies/'. $movie->id. '/comment')); ?>">
                        <?php echo e(csrf_field()); ?>

                        <div class="control<?php echo e($errors->has('comment') ? ' has-error' : ''); ?>">
                            <input id="comment" type="text" class="input" name="comment" placeholder="Comment something....." required autofocus>
                            <?php if($errors->has('comment')): ?>
                                <span class="help-block">
                                    <p id="error"><?php echo e($errors->first('comment')); ?></p>
                                </span>
                            <?php endif; ?>
                        </div>
                        <div class="control">
                            <?php if(Auth::user()): ?>
                                <button type="submit" class="button is-dark">
                                    Submit
                                </button>
                                <?php endif; ?>

                        </div>
                    </form>

            </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
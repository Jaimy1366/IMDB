<?php $__env->startSection('content'); ?>
    <p class="panel-tabs">
        <a  href="./"><<< go back</a>

    </p>
    <div class="container">
        <div class="level">
            <?php echo Form::open(['method'=>'post','url'=>'/series/search/','class'=>'navbar-form navbar-left','role'=>'search']); ?>

                <div class="control search space_bottom">
                    <input type="text" class="input level-item" name="search" placeholder="Search...">
                    <button class="button is-dark level-item" type="submit">
                        <i class="fa fa-search">search</i>
                    </button>
                </div>
            <?php echo Form::close(); ?>

        </div>
        <div class="is-flex">
            <div class="border-right space-top">
                <aside class="menu ">
                    <p class="menu-label">
                        Genres series
                    </p>
                    <ul class="menu-list">
                        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(url('series/'. $genre->name .'/'.$genre->id)); ?>"><?php echo e($genre->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </aside>
            </div>
            <div class="container column">
                <div>

                </div>
                <p class="panel-heading">Series</p>
                <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel-block">
                        <img src="<?php echo e(asset('images/'. $serie->image)); ?>"/>
                        <div><a href="<?php echo e(url('/series/'. $serie->id)); ?>"><?php echo e($serie->title); ?></a></div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Editing Serie <?php echo e($series->title); ?>

        </p>
        <div class="panel-block">
            <?php echo Form::open(['url' => '/admin-dashboard/Series/edit/'. $series['id'] , 'method' => 'patch', 'files' => true]); ?>


            <div>
                <div class="control">
                    <?php echo Form::label("title : ", 'title : ' , ['class' => 'label-info']); ?>

                    <?php echo Form::text('title', $series->title, ['class' => 'input'] ); ?>

                </div>

                <div class="control">
                    <?php echo Form::label("date_aired : ", 'date_aired : ' , ['class' => 'label-info']); ?>

                    <?php echo Form::date('date_aired', $series->date_aired , ['class' => 'input'] ); ?>

                </div>
                <div class="control">
                    <?php echo Form::label("description : ", 'description : ' , ['class' => 'label-info']); ?>

                    <?php echo Form::textarea('description', $series->description , ['class' => 'input'] ); ?>

                </div>

                <div class="control">
                    <?php echo Form::label("img : ", 'img : ', ['class' => 'label-info']); ?>

                    <?php echo Form::file('img'); ?>

                </div>

                <div class="control">
                    <?php echo Form::submit('Verstuur' , ['class' => 'button is-dark']); ?>

                </div>

            </div>

            <?php echo Form::close(); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
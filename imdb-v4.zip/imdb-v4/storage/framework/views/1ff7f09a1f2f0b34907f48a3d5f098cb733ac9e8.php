<?php $__env->startSection('dashboard'); ?>

    <div class="container column is-four-fifths-mobile is-four-fifths-tablet is-two-thirds-desktop panel ">
        <p class="panel-heading has-text-centered">
            <b>
                <?php echo e($serie->title); ?> seasons and episodes control panel
            </b>
        </p>
        <p class="panel-tabs">
            <a  href="../"><<< go back</a>
        </p>
        <div class="panel-block is-flex">
            <div class="container column ">
                <p class="panel-heading">Serie</p>
                <table class="table panel-block">
                    <tr>
                        <td>
                            <h4><b>Title</b></h4>
                        </td>
                        <td>
                            <h4><b>Description</b></h4>
                        </td>

                    </tr>
                    <tr>
                        <td>
                            <h5><?php echo e($serie->title); ?></h5>
                        </td>
                        <td>
                            <h5><?php echo e($serie->description); ?></h5>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="container column ">
                <p class="panel-heading">Seasons and episodes</p>
                <table class="table panel-block">
                    <?php if(count($serie->seasons) > 0): ?>
                        <?php $__currentLoopData = $serie->seasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $season): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <b><?php echo e($season->title); ?></b>
                                </td>
                                <td>
                                    <?php echo Form::open(['url' => 'admin-dashboard/Series/show/season_delete/'.$season->id, 'method' => 'delete']); ?>

                                    <?php echo Form::submit('delete', ['class' => 'button is-danger']); ?>

                                    <?php echo Form::close(); ?>

                                </td>
                                <td>
                                    <a class="button is-link" href="<?php echo e(url('admin-dashboard/Series/show/season_edit/'. $season->id)); ?>">Edit</a>
                                </td>
                            </tr>
                            <?php $__currentLoopData = $season->episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($episode->number); ?> / <?php echo e($episode->name); ?>

                                    </td>
                                    <td>
                                        <?php echo Form::open(['url' => 'admin-dashboard/Series/show/ep_delete/'.$episode->id, 'method' => 'delete']); ?>

                                        <?php echo Form::submit('delete', ['class' => 'button is-danger']); ?>

                                        <?php echo Form::close(); ?>

                                    </td>
                                    <td>
                                        <a class="button is-link" href="<?php echo e(url('admin-dashboard/Series/show/ep_edit/'. $episode->id)); ?>">Edit</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                    <tr>
                        <td>
                            <a class="right-space" href="<?php echo e(url('admin-dashboard/Series/'. $serie['id']. '/show/ep_create')); ?>">
                                Add Episode
                            </a>
                        </td>
                        <td>
                            <a href="<?php echo e(url('admin-dashboard/Series/'. $serie['id']. '/show/season_create')); ?>">
                                Add Season
                            </a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
        <div class="panel-block is-flex">
            <div class="container column">
                <p class="panel-heading">Actors</p>
                <table class="table panel-block">
                    <tr>
                        <td>
                            <h4><b>Actors</b></h4>
                        </td>
                    </tr>
                    <?php $__currentLoopData = $serie->Actor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($actor->name); ?>

                            </td>
                            <td>
                                <?php echo Form::open(['url' => 'admin-dashboard/Series/'.$serie->id.'/show/actor_delete/'.$actor->id, 'method' => 'delete']); ?>

                                <?php echo Form::submit('remove', ['class' => 'button is-dark is-outlined']); ?>

                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(url('admin-dashboard/Series/'. $serie['id']. '/show/add_actor')); ?>">
                                Add existing actor
                            </a>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="container column ">
                <p class="panel-heading">Genres</p>
                <table class="table panel-block">
                    <tr>

                        <td>
                            <h6><b>Genres</b></h6>
                        </td>
                    </tr>
                    <?php $__currentLoopData = $serie->Genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td>
                                <?php echo e($genre->name); ?>

                            </td>
                            <td>
                                <?php echo Form::open(['url' => 'admin-dashboard/Series/'. $serie->id. '/show/genre_delete/'.$genre->id, 'method' => 'delete']); ?>

                                <?php echo Form::submit('remove', ['class' => 'button is-dark is-outlined']); ?>

                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(url('admin-dashboard/Series/'. $serie['id']. '/show/add_genre')); ?>">
                                Add existing genre
                            </a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
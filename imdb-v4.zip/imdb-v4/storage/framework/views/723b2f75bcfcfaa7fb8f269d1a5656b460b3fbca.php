test <?php echo e($genres->name); ?>


<?php $__currentLoopData = $genres->Movie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($movie->title); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
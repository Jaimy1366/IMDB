<?php $__env->startSection('content'); ?>
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Editing Episode <?php echo e($episodes->name); ?>

        </p>

        <div class="panel-block">
            <?php echo Form::open(['url' => 'admin-dashboard/Series/show/ep_edit/'.$episodes->id , 'method' => 'patch']); ?>


            <div>
                <div class="control">
                    <?php echo Form::label("name : ", 'name : ' , ['class' => 'label-info']); ?>

                    <?php echo Form::text('name', $episodes->name, ['class' => 'input'] ); ?>

                </div>

                <div class="control">
                    <?php echo Form::label("number : ", 'number : ' , ['class' => 'label-info']); ?>

                    <?php echo Form::text('number', $episodes->number , ['class' => 'input'] ); ?>

                </div>

                <div class="control">
                    <label for="season_id" class="label-info">Season</label>
                    <select id="season_id"  class="select" name="season_id" required>
                        <?php $__currentLoopData = $seasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $season): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($season->id); ?>"><?php echo e($season->title); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="control">
                    <?php echo Form::submit('Verstuur' , ['class' => 'button is-primary']); ?>

                </div>


            </div>

            <?php echo Form::close(); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
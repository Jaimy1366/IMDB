<?php $__env->startSection('content'); ?>
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Create new Movie
        </p>
        <div class="panel-block">
            <form class="form-horizontal" method="POST" action="<?php echo e(url('admin-dashboard/Movies/create')); ?>" enctype="multipart/form-data">
                <?php echo e(csrf_field()); ?>


                <div class="control<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                    <label for="title" class="label-info">Title</label>
                    <input id="title" type="text" class="input" name="title" placeholder="Title..." required autofocus>
                    <?php if($errors->has('title')): ?>
                        <span class="help-block">
                        <p id="error"><?php echo e($errors->first('title')); ?></p>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="control<?php echo e($errors->has('date_aired') ? ' has-error' : ''); ?>">
                    <label for="date_aired" class="label-info">Date aired</label>
                    <input id="date_aired" type="date" class="input" name="date_aired" placeholder="Date_aired..." required autofocus>
                    <?php if($errors->has('title')): ?>
                        <span class="help-block">
                        <p id="error"><?php echo e($errors->first('date_aired')); ?></p>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="control<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                    <label for="description" class="label-info">description</label>
                    <input id="description" type="text" class="input" name="description" placeholder="Description..." required autofocus>
                    <?php if($errors->has('title')): ?>
                        <span class="help-block">
                        <p id="error"><?php echo e($errors->first('description')); ?></p>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="control<?php echo e($errors->has('duration') ? ' has-error' : ''); ?>">
                    <label for="duration" class="label-info">duration</label>
                    <input id="duration" type="text" class="input" name="duration" placeholder="Duration..." required autofocus>
                    <?php if($errors->has('title')): ?>
                        <span class="help-block">
                        <p id="error"><?php echo e($errors->first('duration')); ?></p>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="control<?php echo e($errors->has('img') ? ' has-error' : ''); ?>">
                    <label for="img" class="label-info">Img</label>
                    <input id="img" type="file" class="input" name="img" placeholder="Img..." required autofocus>
                </div>

                <div class="control">
                    <button type="submit" class="button is-dark">
                        Add movie
                    </button>
                </div>

            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <p class="panel-tabs">
        <a  href="./"><<< go back</a>

    </p>
    <div class="container column is-half">
            <p class="panel-heading">Serie <?php echo e($serie->title); ?></p>
            <div class="panel-block">
                <img src="<?php echo e(asset('images/'. $serie->image)); ?>"/>
            </div>
            <div class="panel-block">
                <?php echo e($serie->description); ?>

            </div>
            <div class="panel-block">
                <?php echo e($serie->date_aired); ?>

            </div>

            <div class="panel-block">
                <?php $__currentLoopData = $serie->Actor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($actor->name); ?>,
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="container column is-full">
                <p class="panel-heading">Seasons and episodes</p>
                <table class="table panel-block">
                    <?php if(count($serie->seasons) > 0): ?>
                        <?php $__currentLoopData = $serie->seasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $season): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td>
                                    <b><?php echo e($season->title); ?></b>
                                </td>
                            </tr>
                            <?php $__currentLoopData = $season->episodes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $episode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($episode->number); ?> / <?php echo e($episode->name); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </table>
            </div>
        <div class="panel-block container column is-full">
            <p class="panel-heading">Comments</p>
            <?php $__currentLoopData = $serie->Comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="panel-block">
                    <?php $__currentLoopData = $user->where('id', $comment->users_id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="panel-block right-space"><?php echo e($users->name); ?></div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php echo e($comment->content); ?>

                    <?php if(Auth::check() && Auth::check() == 'Admin'): ?>
                        <div class="space_left">
                            <?php echo Form::open(['url' => 'series/' . $serie->id .'/'. $comment->id. '/delete', 'method' => 'delete']); ?>

                            <?php echo Form::submit('delete', ['class' => 'button is-danger']); ?>

                            <?php echo Form::close(); ?>

                        </div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <form class="form-horizontal" method="POST" action="<?php echo e(url('/series/'. $serie->id. '/comment')); ?>">
                <?php echo e(csrf_field()); ?>

                <div class="control<?php echo e($errors->has('comment') ? ' has-error' : ''); ?>">
                    <input id="comment" type="text" class="input" name="comment" placeholder="Comment something....." required autofocus>
                    <?php if($errors->has('comment')): ?>
                        <span class="help-block">
                            <p id="error"><?php echo e($errors->first('comment')); ?></p>
                        </span>
                    <?php endif; ?>
                </div>
                <div class="control">
                    <?php if(Auth::check()): ?>
                        <button type="submit" class="button is-dark">
                            Submit
                        </button>
                    <?php endif; ?>

                </div>
            </form>

        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
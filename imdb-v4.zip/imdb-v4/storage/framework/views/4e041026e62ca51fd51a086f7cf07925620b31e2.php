<?php $__env->startSection('content'); ?>
    <p class="panel-tabs">
        <a  href="./"><<< go back</a>

    </p>
    <div class="container">
        <div class="level">
            <?php echo Form::open(['method'=>'post','url'=>'/movies/search/','role'=>'search']); ?>

                <div class="control search space_bottom">
                    <input type="text" class="input level-item" name="search" placeholder="Search...">
                    <button class="button is-dark level-item" type="submit">
                        <i class="fa fa-search">search</i>
                    </button>
                </div>
            <?php echo Form::close(); ?>


        </div>
        <div class="is-flex">
            <div class="border-right space-top">
                <aside class="menu ">
                    <p class="menu-label">
                        Genres movies
                    </p>
                    <ul class="menu-list ">
                        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(url('movies/'. $genre->name .'/'.$genre->id)); ?>"><?php echo e($genre->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </aside>
            </div>
            <div class="container column ">

                <p class="panel-heading">Movies</p>
                <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel-block">
                        <img src="<?php echo e(asset('images/'. $movie->image)); ?>"/>
                        <div><a href="<?php echo e(url('/movies/'. $movie->id)); ?>"><?php echo e($movie->title); ?></a></div>

                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
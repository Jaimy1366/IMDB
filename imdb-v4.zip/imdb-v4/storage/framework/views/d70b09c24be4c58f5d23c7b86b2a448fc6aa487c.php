<?php $__env->startSection('content'); ?>
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Editing Movie <?php echo e($movies->title); ?>

        </p>
        <div class="panel-block">
            <?php echo Form::open(['url' => '/admin-dashboard/Movies/edit/'. $movies['id'] , 'method' => 'patch','files' => true] ); ?>


            <div>
                <div class="control">
                    <?php echo Form::label("title : ", 'title : ' , ['class' => 'label-info']); ?>

                    <?php echo Form::text('title', $movies->title, ['class' => 'input'] ); ?>

                </div>

                <div class="control">
                    <?php echo Form::label("date_aired : ", 'date_aired : ' , ['class' => 'label-info']); ?>

                    <?php echo Form::date('date_aired', $movies->date_aired , ['class' => 'input'] ); ?>

                </div>
                <div class="control">
                    <?php echo Form::label("description : ", 'description : ' , ['class' => 'label-info']); ?>

                    <?php echo Form::textarea('description', $movies->description , ['class' => 'input'] ); ?>

                </div>
                <div class="control">
                    <?php echo Form::label("duration : ", 'duration : ' , ['class' => 'label-info']); ?>

                    <?php echo Form::text('duration', $movies->duration , ['class' => 'input'] ); ?>

                </div>

                <div class="control">
                    <?php echo Form::label("img : ", 'img : ', ['class' => 'label-info']); ?>

                    <?php echo Form::file('img'); ?>

                </div>

                <div class="control">
                    <?php echo Form::submit('Verstuur' , ['class' => 'button is-dark']); ?>

                </div>


            </div>

            <?php echo Form::close(); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
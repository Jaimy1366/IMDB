<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet" type="text/css">
    <style>
        html, body {
            background-color: #fff;
            color: #636b6f;
            font-family: 'Raleway', sans-serif;
            font-weight: 100;
            height: 100vh;
            margin: 0;
        }
        .full-height {
            height: 100vh;
        }
        .flex-center {
            align-items: center;
            display: flex;
            justify-content: center;
        }
        .position-ref {
            position: relative;
        }
        .top-right {
            position: absolute;
            right: 10px;
            top: 18px;
        }
        .content {
            text-align: center;
        }
        .title {
            font-size: 70px;
            position: relative;
        }

        .links > a {
            color: #636b6f;
            padding: 0 25px;
            font-size: 12px;
            font-weight: 600;
            letter-spacing: .1rem;
            text-decoration: none;
            text-transform: uppercase;
        }
        .m-b-md {
            margin-bottom: 30px;
        }
        .user-view td{
            padding-right: 20px;      }
        a{
            text-decoration: none;
            color: hsl(169, 100%, 25%);
        }
        .add_movie_top_line{
            width: 100%;
            height: 5px;
            color: #2a88bd;
            border-top:1px solid #cce5ff;
        }
        .fixed{
            position: fixed;
        }
        .right-space {
            padding-right: 2em;
        }

        .panel {
            margin-top: 5%;
        }

        .panel-heading {
            background-color:hsl(0, 0%, 26%) ;
        }

        .top-spacing{
            margin-top: 20px;
        }

        .control {
            margin-top: 25px;
        }
        #error{
            color: #ff5651;
        }
        .panel-heading{
            color: white;
        }

        .right-space{
            margin-right:0.4em;
        }
        .right-space-small{
            margin-right:0.2em;
        }

        .space-top{
            margin-top: 0.5em;
        }
        .border-right{
            padding-right: 2em;
            margin-right: 2em;
            border-right: 1px solid lightgrey;
        }
        .space_left{
            margin-left: 2em;
        }
        .red{
            color: red;
        }

        .search{
            display: flex;
        }

        .space_bottom{
            margin-bottom: 2em;
        }
        .footer {
            position: fixed;
            right: 0;
            bottom: 0;
            left: 0;
            padding: 1rem;
            background-color: #efefef;
            text-align: center;
        }

        .homepage_content{
            height: 100%;
        }



    </style>
</head>
<body>
<div id="app">
    <section class="hero is-dark main-heading" >
        <div class="hero-head">
            <div class="container">
                <div class="level is-mobile">
                    <div class="title level-left" >
                        <h1 class="level-item title"><a href="<?php echo e(url('/')); ?>"> IMDB</a></h1>
                        <?php if(Auth::check() && Auth::user()->isAdmin() == '1'): ?>
                            <a class="button is-info level-item" href="<?php echo e(url('admin-dashboard')); ?>">
                                Admin-Dashboard
                            </a>
                        <?php endif; ?>
                    </div>


                    <ul class="level-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <li class="right-space"><a href="<?php echo e(route('login')); ?>">Login</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">Register</a></li>
                        <?php else: ?>
                            <li >
                                <a href="#"  data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> / <?php echo e(Auth::user()->roles->name); ?>

                                </a>

                                <ul  role="menu">
                                    <li>
                                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>

                    </ul>

                </div>
                <div class="hero-footer ">
                    <div class="columns">
                        <div class="column is-half is-offset-one-quarter">
                            <nav class="tabs is-boxed is-centered">
                                <ul>
                                    <li>
                                        <a href="<?php echo e(url('/movies')); ?>">Movies</a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(url('/series')); ?>">Series</a>
                                    </li>
                                </ul>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>




    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->yieldContent('dashboard'); ?>
    
</div>



<!-- Scripts -->
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script>
    var myIndex = 0;
    carousel();

    function carousel() {
        var i;
        var x = document.getElementsByClassName("mySlides");
        for (i = 0; i < x.length; i++) {
            x[i].style.display = "none";
        }
        myIndex++;
        if (myIndex > x.length) {myIndex = 1}
        x[myIndex-1].style.display = "block";
        setTimeout(carousel, 5000); // Change image every 2 seconds
    }
</script>
</body>
</html>

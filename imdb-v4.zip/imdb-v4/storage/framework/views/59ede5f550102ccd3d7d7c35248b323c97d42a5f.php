<?php $__env->startSection('content'); ?>
    <p class="panel-tabs">
        <a  href="./"><<< go back</a>

    </p>
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Register
        </p>
        <div class="panel-block">
            <form class="form-horizontal" method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="control<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <label for="name" class="label-info">Name</label>
                    <input id="name" type="text" class="input" name="name" value="<?php echo e(old('name')); ?>" required autofocus>
                    <?php if($errors->has('name')): ?>
                        <span class="help-block">
                        <p id="error"><?php echo e($errors->first('name')); ?></p>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="control<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                    <label for="email" class="label-info">E-Mail Address</label>
                    <input id="email" type="email" class="input" name="email" value="<?php echo e(old('email')); ?>" required>
                    <?php if($errors->has('email')): ?>
                        <span class="help-block">
                        <p id="error"><?php echo e($errors->first('email')); ?></p>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="control<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                    <label for="password" class="label-info">Password</label>
                    <input id="password" type="password" class="input" name="password" required>
                    <?php if($errors->has('password')): ?>
                        <span class="help-block">
                        <p id="error"><?php echo e($errors->first('password')); ?></p>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="control">
                    <label for="password-confirm" class="label-info">Confirm Password</label>
                    <input id="password-confirm" type="password" class="input" name="password_confirmation" required>
                </div>

                <div class="control">
                    <button type="submit" class="button top-spacing">
                        Register
                    </button>
                </div>

            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
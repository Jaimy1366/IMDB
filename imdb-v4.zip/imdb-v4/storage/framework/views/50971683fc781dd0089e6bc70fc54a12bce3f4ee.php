<?php $__env->startSection('dashboard'); ?>

    <div class="container column is-four-fifths-mobile is-four-fifths-tablet is-two-thirds-desktop panel ">
        <p class="panel-heading has-text-centered">
            <b>
                Role controle panel
            </b>
        </p>
        <p class="panel-tabs">
            <a  href="./"><<< go back</a>
        </p>
        <div class="panel-block">
            <table class="table column">
                <tr>
                    <td>
                        <h4><b>Id</b></h4>
                    </td>
                    <td>
                        <h4><b>Name</b></h4>
                    </td>

                </tr>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <h4> <?php echo e($role->id); ?></h4>
                        </td>
                        <td>
                            <h4><?php echo e($role->name); ?></h4>
                        </td>
                        <td>
                            <div >
                                <?php echo Form::open(['url' => 'admin-dashboard/Roles/' . $role['id'], 'method' => 'delete']); ?>

                                <?php echo Form::submit('delete', ['class' => 'button is-danger']); ?>

                                <?php echo Form::close(); ?>

                            </div>

                        </td>
                        <td >
                            <a class="button is-link" href="<?php echo e(url('admin-dashboard/Roles/'. $role->id .'/edit')); ?>">Edit</a>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="add_movie_top_line">
                    <td>
                        <a href="<?php echo e(url('admin-dashboard/Roles/create')); ?>">Add role</a>
                    </td>
                </tr>
            </table>
        </div>
        <?php if(session("message")): ?>
            <div class="panel-block">
                <p class="red"><b><?php echo e(session("message")); ?></b></p>
            </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
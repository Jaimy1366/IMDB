<?php $__env->startSection('content'); ?>
    <p class="panel-tabs">
        <a  href="./"><<< go back</a>

    </p>
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Login
        </p>
        <div class="panel-block">
            <form class="form-horizontal " method="POST" action="<?php echo e(route('login')); ?>">
                <div class="field ">
                    <?php echo e(csrf_field()); ?>


                    <div class="control<?php echo e($errors->has('email') ? ' has-error' : ''); ?>">
                        <label for="email" class="label-primary">E-Mail Address</label>
                        <input id="email" type="email" class="input" name="email" placeholder="E-Mail..." required autofocus>
                        <?php if($errors->has('email')): ?>
                            <span class="help-block">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>

                    <div class="control<?php echo e($errors->has('password') ? ' has-error' : ''); ?>">
                        <label for="password" class="label-primary">Password</label>

                        <input id="password" type="password" class="input" name="password" required>

                        <?php if($errors->has('password')): ?>
                            <span class="help-block">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </span>
                        <?php endif; ?>
                    </div>
                    <div class="control">
                        <div class="checkbox">
                            <label class="label-info">
                                <input class="checkbox" type="checkbox" name="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>> Remember Me
                            </label>
                        </div>
                    </div>
                    <div class="control">

                        <button type="submit" class="button top-spacing">
                            Login
                        </button>
                    </div>

                </div>



            </form>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
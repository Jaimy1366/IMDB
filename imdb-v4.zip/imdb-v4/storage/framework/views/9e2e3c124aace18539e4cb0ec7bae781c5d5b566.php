<?php $__env->startSection('content'); ?>

    <div class=" hero homepage_content is-light">
        <div class="is-flex">
            <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="">

                    <img src="<?php echo e(asset('images/'. $movie->image)); ?>">
                    <div class="caption">
                        <p><?php echo e($movie->title); ?></p>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="is-flex space-top">
            <?php $__currentLoopData = $series; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <div class="">

                    <img class="panel-body" src="<?php echo e(asset('images/'. $serie->image)); ?>">
                    <div class="caption ">
                        <p><?php echo e($serie->title); ?></p>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Create new Season
        </p>
        <p class="panel-tabs">
            <a  href="./"><<< go back</a>

        </p>
        <div class="panel-block">
            <form class="form-horizontal" method="POST" action="<?php echo e(url('admin-dashboard/Series/'. $series['id'].'/show/season_create')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="control<?php echo e($errors->has('title') ? ' has-error' : ''); ?>">
                    <label for="title" class="label-info">Title</label>
                    <input id="title" type="text" class="input" name="title" placeholder="Title..." required autofocus>
                    <?php if($errors->has('title')): ?>
                        <span class="help-block">
                            <p id="error"><?php echo e($errors->first('title')); ?></p>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="control<?php echo e($errors->has('description') ? ' has-error' : ''); ?>">
                    <label for="description" class="label-info">Description</label>
                    <textarea id="description" type="text" class="input" name="description" placeholder="Description..." required autofocus></textarea>
                    <?php if($errors->has('description')): ?>
                        <span class="help-block">
                            <p id="error"><?php echo e($errors->first('description')); ?></p>
                        </span>
                    <?php endif; ?>
                </div>

                <div class="control">
                    <button type="submit" class="button is-dark">
                        Add season
                    </button>
                </div>

            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
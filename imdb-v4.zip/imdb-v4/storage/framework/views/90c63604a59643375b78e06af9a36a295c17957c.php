<?php $__env->startSection('dashboard'); ?>

    <div class="container column is-four-fifths-mobile is-four-fifths-tablet is-two-thirds-desktop panel ">
        <p class="panel-heading has-text-centered">
            <b>
                <?php echo e($movie->title); ?>

            </b>
        </p>
        <p class="panel-tabs">
            <a  href="../"><<< go back</a>

        </p>

        <div class="panel-block level">
            <div class="container column level-left">
                <p class="panel-heading">Movie</p>
                <table class="table panel-block">
                    <tr>
                        <td>
                            <h4><b>Title</b></h4>
                        </td>
                        <td>
                            <h4><b>Date aired</b></h4>
                        </td>
                        <td>
                            <h4><b>Description</b></h4>
                        </td>

                    </tr>
                    <tr>
                        <td>
                            <h5><?php echo e($movie->title); ?></h5>
                        </td>
                        <td>
                            <h5><?php echo e($movie->date_aired); ?></h5>
                        </td>
                        <td>
                            <h5><?php echo e($movie->description); ?></h5>
                        </td>
                    </tr>
                </table>
            </div>

        </div>
        <div class="panel-block is-flex">
            <div class="container column">
                <p class="panel-heading">Actors</p>
                <table class="table panel-block">
                    <tr>
                        <td>
                            <h4><b>Actors</b></h4>
                        </td>
                    </tr>
                    <?php $__currentLoopData = $movie->Actor; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <?php echo e($actor->name); ?>

                            </td>
                            <td>
                                <?php echo Form::open(['url' => 'admin-dashboard/Movies/'.$movie->id.'/show/actor_delete/'.$actor->id, 'method' => 'delete']); ?>

                                <?php echo Form::submit('remove', ['class' => 'button is-dark is-outlined']); ?>

                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(url('admin-dashboard/Movies/'. $movie['id']. '/show/add_actor')); ?>">
                                Add existing actor
                            </a>
                        </td>
                    </tr>
                </table>
            </div>

            <div class="container column ">
                <p class="panel-heading">Genres</p>
                <table class="table panel-block">
                    <tr>

                        <td>
                            <h6><b>Genres</b></h6>
                        </td>
                    </tr>
                    <?php $__currentLoopData = $movie->Genre; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>

                            <td>
                                <?php echo e($genre->name); ?>

                            </td>
                            <td>
                                <?php echo Form::open(['url' => 'admin-dashboard/Movies/'. $movie->id. '/show/genre_delete/'.$genre->id, 'method' => 'delete']); ?>

                                <?php echo Form::submit('remove', ['class' => 'button is-dark is-outlined']); ?>

                                <?php echo Form::close(); ?>

                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(url('admin-dashboard/Movies/'. $movie['id']. '/show/add_genre')); ?>">
                                Add existing genre
                            </a>
                        </td>
                    </tr>
                </table>
            </div>
        </div>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
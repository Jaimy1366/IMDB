<?php $__env->startSection('dashboard'); ?>

    <div class="container column is-four-fifths-mobile is-four-fifths-tablet is-two-thirds-desktop panel ">
        <p class="panel-heading has-text-centered">
            <b>
                Movie control panel
            </b>
        </p>
        <p class="panel-tabs">
            <a  href="./"><<< go back</a>

        </p>
        <div class="panel-block ">
            <table class="table column ">
                <tr>
                    <td>
                        <h4><b>Id</b></h4>
                    </td>

                    <td>
                        <h4><b>Title</b></h4>
                    </td>
                    <td>
                        <h4><b>Duration</b></h4>
                    </td>
                </tr>
                <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <?php echo e($movie->id); ?>

                        </td>
                        <td>
                            <h5><?php echo e($movie->title); ?></h5>
                        </td>
                        <td>
                            <h5><?php echo e($movie->duration); ?></h5>
                        </td>
                        <td>
                            <div >
                                <?php echo Form::open(['url' => 'admin-dashboard/Movies/' . $movie['id'], 'method' => 'delete']); ?>

                                <?php echo Form::submit('delete', ['class' => 'button is-danger']); ?>

                                <?php echo Form::close(); ?>

                            </div>

                        </td>
                        <td >
                            <a class="button is-link" href="<?php echo e(url('admin-dashboard/Movies/'. $movie->id .'/edit')); ?>">Edit</a>
                        </td>
                        <td >
                            <a class="button is-link" href="<?php echo e(url('admin-dashboard/Movies/'. $movie->id .'/show')); ?>">Show</a>
                        </td>
                    </tr>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <tr class="add_movie_top_line">
                    <td>
                        <a href="<?php echo e(url('admin-dashboard/Movies/create')); ?>">Add Movie</a>
                    </td>
                </tr>
            </table>

        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
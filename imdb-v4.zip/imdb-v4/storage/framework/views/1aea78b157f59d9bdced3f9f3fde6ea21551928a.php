<?php $__env->startSection('content'); ?>
    <p class="panel-tabs">
        <a  href="../"><<< go back</a>

    </p>
    <div class="container column">
        <div class="is-flex">
            <div class="border-right space-top">
                <aside class="menu ">
                    <p class="menu-label">
                        Genres series
                    </p>
                    <ul class="menu-list">
                        <?php $__currentLoopData = $all_genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><a href="<?php echo e(url('series/'. $genre->name .'/'.$genre->id)); ?>"><?php echo e($genre->name); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </aside>
            </div>
            <div class="container column">

                <p class="panel-heading"><?php echo e($genres->name); ?></p>
                <?php $__currentLoopData = $genres->Serie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $serie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="panel-block">
                        <img src="<?php echo e(asset('images/'. $serie->image)); ?>"/>
                        <div><a href="<?php echo e(url('/series/'. $serie->id)); ?>"><?php echo e($serie->title); ?></a></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>

    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
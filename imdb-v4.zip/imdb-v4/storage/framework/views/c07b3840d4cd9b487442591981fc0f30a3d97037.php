<?php $__env->startSection('content'); ?>
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Create new Genre
        </p>
        <div class="panel-block">
            <form class="form-horizontal" method="POST" action="<?php echo e(url('admin-dashboard/Genres/create')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="control<?php echo e($errors->has('name') ? ' has-error' : ''); ?>">
                    <label for="name" class="label-info">Name</label>
                    <input id="name" type="text" class="input" name="name" placeholder="Name..." required autofocus>
                    <?php if($errors->has('name')): ?>
                        <span class="help-block">
                        <p id="error"><?php echo e($errors->first('name')); ?></p>
                    </span>
                    <?php endif; ?>
                </div>

                <div class="control">
                    <button type="submit" class="button is-dark">
                        Add genre
                    </button>
                </div>

            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
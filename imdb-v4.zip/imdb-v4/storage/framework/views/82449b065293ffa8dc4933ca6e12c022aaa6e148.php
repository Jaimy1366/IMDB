<?php $__env->startSection('content'); ?>
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Editing Season <?php echo e($seasons->title); ?>

        </p>

        <div class="panel-block">
            <?php echo Form::open(['url' => 'admin-dashboard/Series/show/season_edit/'.$seasons->id , 'method' => 'patch']); ?>


            <div>
                <div class="control">
                    <?php echo Form::label("title : ", 'title : ' , ['class' => 'label-info']); ?>

                    <?php echo Form::text('title', $seasons->title, ['class' => 'input'] ); ?>

                </div>

                <div class="control">
                    <?php echo Form::label("description : ", 'description : ' , ['class' => 'label-info']); ?>

                    <?php echo Form::text('description', $seasons->description , ['class' => 'input'] ); ?>

                </div>

                <div class="control">
                    <?php echo Form::submit('Verstuur' , ['class' => 'button is-dark']); ?>

                </div>


            </div>

            <?php echo Form::close(); ?>

        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->startSection('content'); ?>
    <a href="../" ><h1 class="button is-danger" style="color: white; font-size: 120px" ><b>This function is not working yet</b></h1></a>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
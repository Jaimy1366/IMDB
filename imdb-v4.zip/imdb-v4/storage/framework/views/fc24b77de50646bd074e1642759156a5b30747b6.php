<?php $__env->startSection('content'); ?>
    <div class="container column is-half-mobile is-one-third-tablet is-one-quarter-desktop panel ">
        <p class="panel-heading">
            Add existing Genre
        </p>
        <div class="panel-block">
            <form class="form-horizontal" method="POST" action="<?php echo e(url('admin-dashboard/Movies/'. $movie['id']. '/show/add_genre')); ?>">
                <?php echo e(csrf_field()); ?>


                <div class="control<?php echo e($errors->has('genres_id') ? ' has-error' : ''); ?>">
                    <label for="genres_id" class="label-info">Genre</label>
                    <select id="genres_id" type="text" class="input" name="genres_id" required autofocus>
                        <?php $__currentLoopData = $genres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $genre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($genre->id); ?>"><?php echo e($genre->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>

                <div class="control">
                    <button type="submit" class="button is-dark">
                        Add genre
                    </button>
                </div>

            </form>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
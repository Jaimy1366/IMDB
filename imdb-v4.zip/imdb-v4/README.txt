Mocht je een actor of genre willen verwijderen zorg er dan
eerst voor dat de relaties tussen die en films of series eerst verwijdert worden

de layout wordt later nog aangepast dus let daar maar niet op




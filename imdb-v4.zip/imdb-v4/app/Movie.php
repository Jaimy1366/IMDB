<?php

namespace App;
use Laravel\Scout\Searchable;
use Illuminate\Database\Eloquent\Model;

class Movie extends Model
{
    use Searchable;

    public function Comment()
    {
        return $this->hasMany('App\Comment');
    }

    public function Actor()
    {
        return $this->belongsToMany('App\Actor', 'movie_has_actors', 'movies_id', 'actors_id');
    }

    public function Genre()
    {
        return $this->belongsToMany('App\Genre', 'genre_movies', 'movies_id', 'genres_id');
    }


}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Comment extends Model
{
    public function User()
    {
        return $this->belongsTo('App\User');
    }

    public function Serie()
    {
        return $this->belongsTo('App\Serie');
    }

    public function Movie()
    {
        return $this->belongsTo('App\Movie');
    }

}

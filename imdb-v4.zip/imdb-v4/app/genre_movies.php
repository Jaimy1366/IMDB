<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class genre_movies extends Model
{

}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Actor extends Model
{

    public function Movie()
    {
        //argument actor_movie is een intermediate table en hoeft alleen gebruikt te worden
        // als je de benaming in je database niet op alfabetische volgorde hebt gemaakt.
        // dus movie_actor zou overschreven moeten worden want laravel zoekt naar actor_movie
        //actors_id wijst naar de id van deze model dus Actor model
        //movies_id wijst naar Movie model

        return $this->belongsToMany('App\Movie', 'movie_has_actors', 'actors_id', 'movies_id');
    }


    public function Serie()
    {
        return $this->belongsToMany('App\Serie', 'serie_has_actors', 'actors_id', 'series_id');
    }
}

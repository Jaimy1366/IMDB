<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Episode extends Model
{
    public function Season()
    {
        return $this->belongsTo('App\Season','id','season_id');
    }

}

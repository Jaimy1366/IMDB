<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Genre extends Model
{
    public function Movie()
    {
        return $this->belongsToMany('App\Movie', 'genre_movies', 'genres_id', 'movies_id');
    }

    public function Serie()
    {
        return $this->belongsToMany('App\Serie', 'genre_series', 'genres_id', 'series_id');
    }
}

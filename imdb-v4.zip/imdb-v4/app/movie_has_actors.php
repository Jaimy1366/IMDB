<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class movie_has_actors extends Model
{

}

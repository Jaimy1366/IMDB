<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class serie_has_actors extends Model
{
    //
}

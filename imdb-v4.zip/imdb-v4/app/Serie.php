<?php

namespace App;

use Laravel\Scout\Searchable;
use Illuminate\Database\Eloquent\Model;

class Serie extends Model
{

    use Searchable;

    public function seasons()
    {
        return $this->hasMany('App\Season',  'series_id', 'id');
    }

    public function Comment()
    {
        return $this->hasMany('App\Comment');
    }

    public function Actor()
    {
        return $this->belongsToMany('App\Actor' , 'serie_has_actors', 'series_id', 'actors_id');
    }

    public function Genre()
    {
        return $this->belongsToMany('App\Genre', 'genre_series', 'series_id', 'genres_id');
    }


}

<?php

namespace App\Http\Controllers;

use App\Genre;
use App\genre_series;
use App\genre_movies;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

class GenreController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $genres = Genre::all();
        return view('admin.show.genres', compact('genres'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        $genre = new Genre();

        $genre->name = Input::get('name');
        $genre->save();

        return redirect::to('admin-dashboard/Genres');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Genre  $genre
     * @return \Illuminate\Http\Response
     */
    public function show(Genre $genre)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Genre  $genre
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $genres = Genre::find($id);
        return view('admin.edit.genres', compact('genres'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Genre  $genre
     * @return \Illuminate\Http\Response
     */
    public function update($id)
    {
        $genre = Genre::find($id);
        $genre->name= Input::get('name');
        $genre->save();

        return redirect::to('admin-dashboard/Genres');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Genre  $genre
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $genre_movie = genre_movies::all()->where('genres_id', $id);
        $genre_serie = genre_series::all()->where('genres_id', $id);
        $genres = Genre::find($id);

        //not yet replaced by onDelete('cascade')
        if(count($genre_movie) > 0 OR count($genre_serie) > 0){
            $message = "It seems that this genre is currently being used, make sure that no serie or movie has this genre before deleting it ";
            //return var_dump($message);
            return redirect('admin-dashboard/Genres')->with('message',$message);
        }else{
            $genres->delete();
        }

        return redirect::to('admin-dashboard/Genres');
    }
}

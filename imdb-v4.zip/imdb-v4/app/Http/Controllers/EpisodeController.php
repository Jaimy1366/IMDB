<?php

namespace App\Http\Controllers;

use App\Episode;

use App\Season;
use App\Serie;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

class EpisodeController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($id)
    {
        $serie = Serie::find($id);
        return view('admin.create.episodes', compact('serie'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store($id)
    {
        $series = Serie::find($id);

        $episode = new Episode();
        $episode->name = Input::get('name');
        $episode->number = Input::get('number');
        $episode->season_id = Input::get('season_id');
        $episode->save();

        return redirect::to('admin-dashboard/Series/'.$series['id'].'/show');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Episode  $episode
     * @return \Illuminate\Http\Response
     */
    public function show(Episode $id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Episode  $episode
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {

        $episodes = Episode::find($id);
        //$seasons = Season::where('id', $episodes->season_id)->get();
        $seasons = Season::all();
        return view('admin.edit.episodes', compact('episodes', 'seasons', 'series'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Episode  $episode
     * @return \Illuminate\Http\Response
     */
    public function update($id)
    {
        $episode = Episode::find($id);
        $episode->name = Input::get('name');
        $episode->number = Input::get('number');
        $episode->season_id = Input::get('season_id');
        $episode->save();

        return redirect::to('admin-dashboard/Series');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Episode  $episode
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $episodes = Episode::find($id);
        $episodes->delete();


        return redirect::to('admin-dashboard/Series');
    }
}

<?php

namespace App\Http\Controllers;

use App\Actor;
use App\Genre;
use App\Movie;
use App\Serie;
use App\movie_has_actors;
use App\genre_movies;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\File;
use Symfony\Component\HttpFoundation\File\UploadedFile;
use Intervention\Image\Facades\Image;

class MovieController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $movies = Movie::all();
        return view('admin.show.movies', compact('movies'));
    }

    public function movies(){
        $genres = Genre::all();
        $movies = Movie::all();

        return view('movie_homepage', compact('movies' , 'genres'));
    }

    public function genre_movies($Genre_name, $Genre_id ){
        //shows all the series that have this specific genre
        $genres = Genre::find($Genre_id);
        $all_genres = Genre::all();
        return view('genres.movies.genre_movies' , compact('genres', 'all_genres', 'is_active'));
        //return view('genres.movies.'.$Genre_name, compact('genres'));
    }


    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function add_genre_page($id){
        $movie = Movie::find($id);
        $genres = Genre::all();

        return view('admin.add.movie_genre', compact('movie', 'genres'));
    }

    public function add_actor_page($id){
        $movie = Movie::find($id);
        $actors = Actor::all();

        return view('admin.add.movie_actor', compact('movie', 'actors'));
    }

    public function add_genre($id){

        //stores the new relation between an genre and the movie
        $genre = new genre_movies();
        $genre->movies_id = $id;
        $genre->genres_id = Input::get('genres_id');
        $genre->save();
        return \redirect('admin-dashboard/Movies');
    }

    public function add_actor($id){
        //stores the new relation between an actor and the movie
        $genre = new movie_has_actors();
        $genre->movies_id = $id;
        $genre->actors_id = Input::get('actors_id');
        $genre->save();
        return \redirect('admin-dashboard/Movies');
    }
    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $movie = new Movie();


        $movie->title = Input::get('title');
        $movie->date_aired = Input::get('date_aired');
        $movie->description = Input::get('description');
        $movie->duration = Input::get('duration');

        //checks if input has file, makes a name with a timestamp, creates an location
        //creates image, resizes image, and saves the image in de image folder
        if($request->hasFile('img')){
            $image = $request->file('img');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('images/' . $filename);
            Image::make($image)->resize(400, 200)->save($location);

            $movie->image = $filename;
        }
        $movie->save();

        return redirect::to('admin-dashboard/Movies');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Movie  $movie
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $movie = Movie::find($id);
        return view('admin.show.movie_single', compact('movie'));
    }

    public function show_public($movie_id){
        //public means that every visitor can see this
        $movie = Movie::find($movie_id);
        $user = User::all();

        return view('genres.movies.show.movie' , compact('movie', 'user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Movie  $movie
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $movies = Movie::find($id);
        return view('admin.edit.movies', compact('movies'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Movie  $movie
     * @return \Illuminate\Http\Response
     */
    public function update($id, Request $request)
    {
        $movie = Movie::find($id);
        $movie->title= Input::get('title');
        $movie->date_aired= Input::get('date_aired');
        $movie->description= Input::get('description');
        $movie->duration= Input::get('duration');

        if($request->hasFile('img')){
            $image = $request->file('img');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('images/' . $filename);
            Image::make($image)->resize(400, 200)->save($location);

            $movie->image = $filename;
        }

        $movie->save();

        return redirect::to('admin-dashboard/Movies');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Movie  $movie
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $movies = Movie::find($id);
        $movies->delete();

        return redirect::to('admin-dashboard/Movies');
    }

    public function destroy_actor($id_movie, $id_actor){
        //this function deletes the relation between an actor and the movie in the pivot table
        $actor_movie = movie_has_actors::all()->where('movies_id' , $id_movie)->where('actors_id', $id_actor);
        foreach ($actor_movie as $actor_movies){

            $actor_movies->delete();
        }
        return redirect::to('admin-dashboard/Movies/'.$id_movie.'/show');
    }

    public function destroy_genre($id_movie, $id_genre){
        //this function removes the relation between an genre and the movie in the pivot table
        $genre_movie = genre_movies::all()->where('movies_id' , $id_movie)->where('genres_id', $id_genre);
        foreach ($genre_movie as $genre_movies){
            $genre_movies->delete();
        }
        return redirect::to('admin-dashboard/Movies/'.$id_movie.'/show');
    }
}

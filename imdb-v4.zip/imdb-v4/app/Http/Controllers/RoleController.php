<?php

namespace App\Http\Controllers;

use App\Role;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

class RoleController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $roles = Role::all();
        return view('admin.show.roles', compact('roles'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        $role = new Role();

        $role->name = Input::get('name');
        $role->save();

        return redirect::to('admin-dashboard/Roles');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function show(Role $role)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $roles = Role::find($id);
        return view('admin.edit.roles', compact('roles'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function update($id)
    {
        $role = Role::find($id);
        $role->name= Input::get('name');
        $role->save();

        return redirect::to('admin-dashboard/Roles');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Role  $role
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $roles = Role::find($id);
        $user = User::all();
        if($roles->id === 1 OR $roles->id === 2){
            //this checks if the role you want to delete is an admin or user role
            //these roles should not be abe to get deleted because they will always be in use
            $message = "This Role cannot be deleted";
            return redirect('admin-dashboard/Roles')->with('message',$message);
        } elseif(count($user->where('roles_id' , $id)) > 0){
            //not yet replaced by onDelete('cascade')
            $message = "It seems that this role is currently being used, make sure that no user has this role before deleting it ";
            return redirect('admin-dashboard/Roles')->with('message',$message);
        }else{
            $roles->delete();
        }


        return redirect::to('admin-dashboard/Roles');
    }
}

<?php

namespace App\Http\Controllers;

use App\Season;
use App\Serie;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

class SeasonController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($id)
    {
        $series = Serie::find($id);
        return view('admin.create.seasons', compact('series'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store($id)
    {
        $series = Serie::find($id);

        $season = new Season();

        $season->title = Input::get('title');
        $season->description = Input::get('description');
        $season->series_id = $series['id'];
        $season->save();

        return redirect::to('admin-dashboard/Series/'.$series['id'].'/show');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Season  $season
     * @return \Illuminate\Http\Response
     */
    public function show(Season $season)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Season  $season
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //$series = Serie::find($id);

        $seasons = Season::find($id);

        //return var_dump($episodes->number);
        return view('admin.edit.seasons', compact('seasons'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Season  $season
     * @return \Illuminate\Http\Response
     */
    public function update($id)
    {
        $season = Season::find($id);
        $season->title = Input::get('title');
        $season->description = Input::get('description');
        $season->save();

        return redirect::to('admin-dashboard/Series');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Season  $season
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $seasons = Season::find($id);


        $seasons->delete();

        return redirect::to('admin-dashboard/Series');
    }
}

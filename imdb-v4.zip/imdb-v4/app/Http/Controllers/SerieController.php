<?php

namespace App\Http\Controllers;

use App\Serie;
use App\User;
use App\Episode;
use App\Season;
use App\Actor;
use App\Genre;
use App\serie_has_actors;
use App\genre_series;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;
use Intervention\Image\Facades\Image;

class SerieController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $series = Serie::all();

        return view('admin.show.series', compact('series'));
    }

    public function show_public($serie_id){
        //public means that every visitor can see this
        $serie = Serie::find($serie_id);
        $user = User::all();

        return view('genres.series.show.serie' , compact('serie', 'user'));
    }

    public function series(){
        $genres = Genre::all();
        $series = Serie::all();

        return view('serie_homepage', compact('series' , 'genres'));
    }

    public function genre_series($Genre_name, $Genre_id ){
        //shows the series that have this specific genre
        $genres = Genre::find($Genre_id);
        $all_genres = Genre::all();
        return view('genres.series.genre_series' , compact('genres', 'all_genres'));

    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function add_genre_page($id){
        $serie = Serie::find($id);
        $genres = Genre::all();

        return view('admin.add.serie_genre', compact('serie', 'genres'));
    }

    public function add_actor_page($id){
        $serie = Serie::find($id);
        $actors = Actor::all();

        return view('admin.add.serie_actor', compact('serie', 'actors'));
    }

    public function add_genre($id){
        //stores the new relation between an genre and the serie
        $genre = new genre_series();
        $genre->series_id = $id;
        $genre->genres_id = Input::get('genres_id');
        $genre->save();
        return \redirect('admin-dashboard/Series');
    }

    public function add_actor($id){
        //stores the new relation between an actor and the serie
        $genre = new serie_has_actors();
        $genre->series_id = $id;
        $genre->actors_id = Input::get('actors_id');
        $genre->save();
        return \redirect('admin-dashboard/Series');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $serie = new Serie();

        $serie->title = Input::get('title');
        $serie->description = Input::get('description');
        $serie->date_aired = Input::get('date_aired');

        //checks if input has file, makes a name with a timestamp, creates an location
        //creates image, resizes image, and saves the image in de image folder
        if($request->hasFile('img')){
            $image = $request->file('img');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('images/' . $filename);
            Image::make($image)->resize(400, 200)->save($location);

            $serie->image = $filename;
        }

        $serie->save();

        return redirect::to('admin-dashboard/Series');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Serie  $serie
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $serie = Serie::find($id);
        //return var_dump($serie);
        return view('admin.show.serie_episodes', compact('serie'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Serie  $serie
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $series = Serie::find($id);
        return view('admin.edit.series', compact('series'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Serie  $serie
     * @return \Illuminate\Http\Response
     */
    public function update($id, Request $request)
    {
        $serie = Serie::find($id);
        $serie->title= Input::get('title');
        $serie->description= Input::get('description');
        $serie->date_aired= Input::get('date_aired');
        if($request->hasFile('img')){
            $image = $request->file('img');
            $filename = time() . '.' . $image->getClientOriginalExtension();
            $location = public_path('images/' . $filename);
            Image::make($image)->resize(400, 200)->save($location);

            $serie->image = $filename;
        }
        $serie->save();

        return redirect::to('admin-dashboard/Series');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Serie  $serie
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $series = Serie::find($id);
        $series->delete();

        return redirect::to('admin-dashboard/Series');
    }

    public function destroy_actor($id_serie, $id_actor){
        //this function deletes the relation between an actor and the serie in the pivot table
        $actor_serie = serie_has_actors::all()->where('series_id' , $id_serie)->where('actors_id', $id_actor);
        foreach ($actor_serie as $actor_series){
            $actor_series->delete();
        }
        return redirect::to('admin-dashboard/Series/'.$id_serie.'/show');
    }

    public function destroy_genre($id_serie, $id_genre){
        //this function deletes the relation between an genre and the serie in the pivot table
        $genre_serie = genre_series::all()->where('series_id' , $id_serie)->where('genres_id', $id_genre);
        foreach ($genre_serie as $genre_series){
            $genre_series->delete();
        }
        return redirect::to('admin-dashboard/Series/'.$id_serie.'/show');
    }
}

<?php

namespace App\Http\Controllers;

use App\Actor;
use App\movie_has_actors;
use App\serie_has_actors;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

class ActorController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $actors = Actor::all();
        return view('admin.show.actors', compact('actors'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store()
    {
        $actor = new Actor();

        $actor->name = Input::get('name');
        $actor->save();

        return redirect::to('admin-dashboard/Actors');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Actor  $actor
     * @return \Illuminate\Http\Response
     */
    public function show(Actor $actor)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Actor  $actor
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $actors = Actor::find($id);
        return view('admin.edit.actors', compact('actors'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Actor  $actor
     * @return \Illuminate\Http\Response
     */
    public function update($id)
    {
        $actor = Actor::find($id);
        $actor->name= Input::get('name');
        $actor->save();

        return redirect::to('admin-dashboard/Actors');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Actor  $actor
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $actors = Actor::find($id);
        $movie_has_actors = movie_has_actors::all();
        $serie_has_actors = serie_has_actors::all();

        //not yet replaced by onDelete('cascade')
        if(count($movie_has_actors->where('actors_id' , $id)) > 0 OR count($serie_has_actors->where('actors_id' , $id)) > 0){
            $message = "Please first delete this actor from a movie or serie  ".$actors->name." is playing in";
            //return var_dump($message);
            return redirect('admin-dashboard/Actors')->with('message',$message);
        }else{
            $actors->delete();
        }



        return redirect::to('admin-dashboard/Actors');
    }
}

<?php

namespace App\Http\Controllers;
use App\Genre;
use App\Movie;
use App\Serie;
use Illuminate\Http\Request;

class searchController extends Controller
{
    public function search_movies(){
        $genres = Genre::all();
        if(!empty(request('search'))){
            $search = request('search');
            $resultMovie = Movie::where('title', 'like', '%'. $search. '%')->get();
        }
        //return var_dump($resultMovie);
        return view('genres.movies.search_movies', compact('resultMovie' , 'resultShow', 'genres'));
    }

    public function search_series(){
        $genres = Genre::all();
        if(!empty(request('search'))){
            $search = request('search');
            $resultShow = Serie::where('title', 'like', '%'. $search. '%')->get();
        }
        //return var_dump($resultShow);
        return view('genres.series.search_series', compact('resultShow', 'genres'));
    }
}

<?php

namespace App\Http\Controllers;

use App\Comment;
use App\Movie;
use App\Serie;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Input;

class CommentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store_movie($movie_id)
    {
        $movie = Movie::find($movie_id);
        $user_id = Auth::id();

        if(Auth::check()){
            $comment = new Comment();
            $comment->content = Input::get('comment');
            $comment->movie_id = $movie_id;
            $comment->users_id = $user_id;
            $comment->save();

            return redirect::to('/movies/'.$movie['id']);
        }else{
            return redirect('/login');
        }
    }

    public function store_serie($serie_id)
    {
        $serie = Serie::find($serie_id);
        $user_id = Auth::id();

        if(Auth::check()){
            $comment = new Comment();
            $comment->content = Input::get('comment');
            $comment->serie_id = $serie_id;
            $comment->users_id = $user_id;
            $comment->save();

            return redirect::to('/series/'.$serie['id']);
        }else{
            return redirect('/login');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Comment  $comment
     * @return \Illuminate\Http\Response
     */
    public function show(Comment $comment)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Comment  $comment
     * @return \Illuminate\Http\Response
     */
    public function edit(Comment $comment)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Comment  $comment
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Comment $comment)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Comment  $comment
     * @return \Illuminate\Http\Response
     */
    public function destroy(Comment $comment)
    {
        //
    }

    public function destroy_mc( $movie_id, $comment_id){
        //movie comments
        $comment = Comment::find($comment_id);
        $comment->delete();

        return redirect::to('/movies/'. $movie_id);
    }

    public function destroy_sc($serie_id, $comment_id){
        //serie  comment
        $comment = Comment::find($comment_id);
        $comment->delete();

        return redirect::to('/series/'. $serie_id);
    }
}
